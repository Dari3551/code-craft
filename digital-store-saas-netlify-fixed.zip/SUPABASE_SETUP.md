# 🚀 دليل إعداد Supabase - Digital Store SaaS Platform

## ما هي Supabase؟

**Supabase** هي منصة سحابية مفتوحة المصدر توفر قاعدة بيانات **PostgreSQL** احترافية مع واجهة رسومية سهلة الاستخدام. وهي الخيار الأمثل لتطبيقات الـ SaaS.

---

## 📋 الخطوات الأساسية

### 1️⃣ إنشاء حساب Supabase

1. اذهب إلى [supabase.com](https://supabase.com)
2. اضغط **"Start your project"**
3. سجل دخول باستخدام GitHub أو البريد الإلكتروني
4. أكمل عملية التسجيل

### 2️⃣ إنشاء مشروع جديد

1. في لوحة التحكم، اضغط **"New Project"**
2. أدخل اسم المشروع: `digital-store-saas`
3. اختر كلمة مرور قوية للـ Database
4. اختر المنطقة الجغرافية الأقرب إليك
5. اضغط **"Create new project"** وانتظر 2-3 دقائق

### 3️⃣ الحصول على رابط الاتصال

بعد إنشاء المشروع:

1. اذهب إلى **Settings** > **Database**
2. انسخ **Connection String** (يبدأ بـ `postgresql://`)
3. الصيغة ستكون:
   ```
   postgresql://postgres:your_password@db.supabase.co:5432/postgres
   ```

### 4️⃣ تحديث ملف .env

افتح ملف `.env` في مشروعك وأضف:

```env
# قاعدة البيانات - Supabase
DATABASE_URL=postgresql://postgres:your_password@db.supabase.co:5432/postgres
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=your_anon_key_here
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key_here
```

**كيفية الحصول على المفاتيح:**
- اذهب إلى **Settings** > **API**
- ستجد `anon` و `service_role` keys

### 5️⃣ تثبيت المكتبات المطلوبة

```bash
npm install pg
```

---

## 🔐 إعدادات الأمان

### تفعيل Row Level Security (RLS)

1. اذهب إلى **Authentication** > **Policies**
2. فعّل **Row Level Security** لكل جدول
3. أضف سياسات للتحكم في الوصول

مثال:
```sql
CREATE POLICY "Users can only access their own stores"
ON stores
FOR SELECT
USING (auth.uid() = user_id);
```

### إنشاء Role للتطبيق

```sql
CREATE ROLE app_user WITH LOGIN PASSWORD 'secure_password';
GRANT CONNECT ON DATABASE postgres TO app_user;
GRANT USAGE ON SCHEMA public TO app_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO app_user;
```

---

## 📊 إنشاء الجداول يدوياً (اختياري)

إذا أردت إنشاء الجداول يدوياً بدلاً من الكود:

### 1. جدول المستخدمين

```sql
CREATE TABLE users (
  id VARCHAR(36) PRIMARY KEY,
  phone_number VARCHAR(20) UNIQUE NOT NULL,
  email VARCHAR(255) UNIQUE,
  name VARCHAR(255),
  is_verified BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 2. جدول المتاجر

```sql
CREATE TABLE stores (
  id VARCHAR(36) PRIMARY KEY,
  user_id VARCHAR(36) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  store_name VARCHAR(255) NOT NULL,
  store_slug VARCHAR(255) UNIQUE NOT NULL,
  description TEXT,
  logo_url VARCHAR(500),
  banner_url VARCHAR(500),
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 3. جدول المنتجات

```sql
CREATE TABLE products (
  id VARCHAR(36) PRIMARY KEY,
  store_id VARCHAR(36) NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
  category_id VARCHAR(36),
  name VARCHAR(255) NOT NULL,
  description TEXT,
  price DECIMAL(10, 2) NOT NULL,
  cost DECIMAL(10, 2),
  stock INTEGER DEFAULT 0,
  sku VARCHAR(100),
  image_url VARCHAR(500),
  is_digital BOOLEAN DEFAULT FALSE,
  digital_file_url VARCHAR(500),
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 4. جدول الطلبات

```sql
CREATE TABLE orders (
  id VARCHAR(36) PRIMARY KEY,
  store_id VARCHAR(36) NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
  customer_name VARCHAR(255) NOT NULL,
  customer_email VARCHAR(255),
  customer_phone VARCHAR(20),
  total_amount DECIMAL(10, 2) NOT NULL,
  discount_amount DECIMAL(10, 2) DEFAULT 0,
  final_amount DECIMAL(10, 2) NOT NULL,
  payment_method VARCHAR(50),
  payment_status VARCHAR(50) DEFAULT 'pending',
  order_status VARCHAR(50) DEFAULT 'pending',
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

## 🔗 الاتصال من التطبيق

### استخدام pg (Node.js)

```javascript
const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: {
    rejectUnauthorized: false, // مهم لـ Supabase
  },
});

// تنفيذ استعلام
pool.query('SELECT * FROM users', (err, res) => {
  if (err) console.error(err);
  else console.log(res.rows);
});
```

---

## 📱 إعدادات SMS (Twilio)

### 1. إنشاء حساب Twilio

1. اذهب إلى [twilio.com](https://www.twilio.com)
2. اضغط **"Sign Up"**
3. تحقق من رقم الهاتف
4. أكمل الإعداد

### 2. الحصول على بيانات الاتصال

1. اذهب إلى **Console Dashboard**
2. انسخ:
   - **Account SID**
   - **Auth Token**
   - **Phone Number** (رقم Twilio الخاص بك)

### 3. تحديث .env

```env
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=your_auth_token_here
TWILIO_PHONE_NUMBER=+1234567890
```

### 4. إرسال OTP

```javascript
const twilio = require('twilio');

const client = twilio(
  process.env.TWILIO_ACCOUNT_SID,
  process.env.TWILIO_AUTH_TOKEN
);

client.messages.create({
  body: `Your OTP is: 123456`,
  from: process.env.TWILIO_PHONE_NUMBER,
  to: '+966501234567',
});
```

---

## 💳 إعدادات Stripe (الدفع)

### 1. إنشاء حساب Stripe

1. اذهب إلى [stripe.com](https://stripe.com)
2. اضغط **"Start now"**
3. أكمل عملية التسجيل

### 2. الحصول على المفاتيح

1. اذهب إلى **Developers** > **API Keys**
2. انسخ:
   - **Secret Key** (sk_test_...)
   - **Publishable Key** (pk_test_...)

### 3. تحديث .env

```env
STRIPE_SECRET_KEY=sk_test_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
STRIPE_PUBLISHABLE_KEY=pk_test_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

### 4. معالجة الدفع

```javascript
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

const paymentIntent = await stripe.paymentIntents.create({
  amount: 10000, // بالفلس (100 ريال)
  currency: 'sar',
  payment_method_types: ['card'],
});
```

---

## 🚀 النشر على الإنتاج

### 1. تحديث متغيرات البيئة

```bash
# استخدم مفاتيح Stripe الحقيقية (Live)
STRIPE_SECRET_KEY=sk_live_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
STRIPE_PUBLISHABLE_KEY=pk_live_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

# استخدم كلمة مرور قوية جداً
JWT_SECRET=generate_strong_random_key_here
```

### 2. تفعيل HTTPS

تأكد من أن موقعك يستخدم HTTPS (SSL Certificate)

### 3. النسخ الاحتياطية

في Supabase:
1. اذهب إلى **Settings** > **Backups**
2. فعّل النسخ الاحتياطية التلقائية

---

## 🐛 استكشاف الأخطاء

### خطأ: "connection refused"
- تحقق من رابط الاتصال
- تأكد من تفعيل SSL

### خطأ: "permission denied"
- تحقق من صلاحيات المستخدم
- تأكد من كلمة المرور

### خطأ: "relation does not exist"
- تأكد من إنشاء الجداول
- شغّل ملف التهيئة (initialization script)

---

## 📞 الدعم

- [Supabase Docs](https://supabase.com/docs)
- [Twilio Docs](https://www.twilio.com/docs)
- [Stripe Docs](https://stripe.com/docs)

---

**تم! الآن أنت جاهز للبدء مع Supabase! 🎉**
