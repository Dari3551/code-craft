# 🤖 دليل ربط البوتات - Digital Store SaaS Platform

هذا الدليل يشرح كيفية ربط أي بوت (WhatsApp، Discord، Telegram، إلخ) بمتجرك والحصول على جميع البيانات **وإدارة المتجر بصلاحيات المدير الكاملة**.

---

## 📌 المحتويات

1. [كيفية الحصول على Master API Key](#كيفية-الحصول-على-master-api-key)
2. [أمثلة الاستخدام الأساسية](#أمثلة-الاستخدام-الأساسية)
3. [Endpoints المتاحة](#endpoints-المتاحة)
4. [أمثلة عمليات الإدارة (CRUD)](#أمثلة-عمليات-الإدارة-crud)
5. [أمثلة عملية للبوتات](#أمثلة-عملية-للبوتات)

---

## 🔑 كيفية الحصول على Master API Key

### الخطوة 1: الدخول إلى لوحة التحكم
1. سجل دخول إلى متجرك
2. اذهب إلى **الإعدادات** > **API & Integrations**

### الخطوة 2: توليد مفتاح جديد
1. اضغط على **"Generate New API Key"**
2. أعطِ المفتاح اسماً (مثل: "WhatsApp Bot" أو "Discord Bot")
3. اختر **"Full Access"** (صلاحيات كاملة)
4. اضغط **"Generate"**

### الخطوة 3: نسخ المفتاح
1. سيظهر لك المفتاح مرة واحدة فقط
2. **انسخه وحفظه في مكان آمن**
3. لن تتمكن من رؤيته مرة أخرى

---

## 📚 أمثلة الاستخدام الأساسية

### استخدام cURL

```bash
# الحصول على ملخص المتجر
curl -X GET "https://yourdomain.com/api/master/summary" \
  -H "X-API-Key: your_master_api_key"

# الحصول على جميع الطلبات
curl -X GET "https://yourdomain.com/api/master/orders" \
  -H "X-API-Key: your_master_api_key"

# الحصول على جميع المنتجات
curl -X GET "https://yourdomain.com/api/master/products" \
  -H "X-API-Key: your_master_api_key"

# إضافة منتج جديد
curl -X POST "https://yourdomain.com/api/master/products" \
  -H "X-API-Key: your_master_api_key" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "دورة تطوير الويب",
    "price": 299,
    "description": "دورة شاملة لتعلم تطوير الويب",
    "stock": 100
  }'
```

### استخدام JavaScript/Node.js

```javascript
const API_KEY = 'your_master_api_key';
const BASE_URL = 'https://yourdomain.com/api/master';

// دالة عامة لإرسال الطلبات
async function apiCall(endpoint, method = 'GET', body = null) {
  const options = {
    method,
    headers: {
      'X-API-Key': API_KEY,
      'Content-Type': 'application/json',
    },
  };

  if (body) {
    options.body = JSON.stringify(body);
  }

  const response = await fetch(`${BASE_URL}${endpoint}`, options);
  return response.json();
}

// الحصول على ملخص المتجر
const summary = await apiCall('/summary');
console.log(summary);

// الحصول على جميع الطلبات
const orders = await apiCall('/orders');
console.log(orders);
```

### استخدام Python

```python
import requests

API_KEY = 'your_master_api_key'
BASE_URL = 'https://yourdomain.com/api/master'

headers = {
    'X-API-Key': API_KEY,
    'Content-Type': 'application/json'
}

# الحصول على ملخص المتجر
response = requests.get(f'{BASE_URL}/summary', headers=headers)
print(response.json())

# الحصول على جميع الطلبات
response = requests.get(f'{BASE_URL}/orders', headers=headers)
print(response.json())
```

---

## 🔌 Endpoints المتاحة

### 📊 ملخص المتجر

```
GET /api/master/summary
```

**الرد:**
```json
{
  "success": true,
  "data": {
    "store": {
      "id": "store-123",
      "name": "متجري الرائع",
      "slug": "my-store",
      "description": "وصف المتجر"
    },
    "stats": {
      "productsCount": 50,
      "ordersCount": 150,
      "totalRevenue": 25000,
      "customersCount": 120
    }
  }
}
```

---

### 📦 المنتجات

#### الحصول على جميع المنتجات
```
GET /api/master/products?limit=100&offset=0
```

#### إضافة منتج جديد
```
POST /api/master/products
```

**البيانات:**
```json
{
  "name": "اسم المنتج",
  "price": 299,
  "description": "وصف المنتج",
  "cost": 150,
  "stock": 100,
  "categoryId": "cat-123",
  "sku": "SKU-001",
  "imageUrl": "https://example.com/image.jpg",
  "isDigital": false,
  "digitalFileUrl": null
}
```

#### تعديل منتج
```
PUT /api/master/products/:productId
```

#### حذف منتج
```
DELETE /api/master/products/:productId
```

---

### 🏷️ الفئات

#### الحصول على جميع الفئات
```
GET /api/master/categories
```

#### إضافة فئة جديدة
```
POST /api/master/categories
```

**البيانات:**
```json
{
  "name": "اسم الفئة",
  "description": "وصف الفئة",
  "icon": "📚"
}
```

#### تعديل فئة
```
PUT /api/master/categories/:categoryId
```

#### حذف فئة
```
DELETE /api/master/categories/:categoryId
```

---

### 🎟️ الكوبونات

#### الحصول على جميع الكوبونات
```
GET /api/master/coupons
```

#### إضافة كوبون جديد
```
POST /api/master/coupons
```

**البيانات:**
```json
{
  "code": "SAVE50",
  "discountType": "percentage",
  "discountValue": 50,
  "minPurchase": 100,
  "maxUses": 100,
  "expiresAt": "2024-12-31"
}
```

#### تعديل كوبون
```
PUT /api/master/coupons/:couponId
```

#### حذف كوبون
```
DELETE /api/master/coupons/:couponId
```

---

### 📋 الطلبات

#### الحصول على جميع الطلبات
```
GET /api/master/orders?status=pending&limit=100&offset=0
```

#### إضافة طلب جديد
```
POST /api/master/orders
```

**البيانات:**
```json
{
  "customerName": "أحمد محمد",
  "customerEmail": "ahmed@example.com",
  "customerPhone": "+966501234567",
  "items": [
    {
      "productId": "prod-1",
      "quantity": 2
    }
  ],
  "notes": "ملاحظات إضافية"
}
```

#### تحديث حالة الطلب
```
PUT /api/master/orders/:orderId
```

**البيانات:**
```json
{
  "status": "completed",
  "paymentStatus": "paid"
}
```

#### حذف طلب
```
DELETE /api/master/orders/:orderId
```

---

### 👥 العملاء

#### الحصول على جميع العملاء
```
GET /api/master/customers
```

---

### 💰 الإحصائيات المالية

```
GET /api/master/stats/financial
```

---

### 🔍 البحث

```
GET /api/master/search?query=keyword&type=products
```

---

## 🎯 أمثلة عمليات الإدارة (CRUD)

### 1️⃣ إضافة منتج جديد

#### JavaScript
```javascript
async function addProduct() {
  const newProduct = {
    name: "دورة تطوير الويب المتقدمة",
    price: 499,
    description: "دورة شاملة تغطي React, Node.js, MongoDB",
    cost: 100,
    stock: 50,
    categoryId: "cat-123",
    sku: "WEB-COURSE-001",
    imageUrl: "https://example.com/course.jpg",
    isDigital: true,
    digitalFileUrl: "https://example.com/course-files.zip"
  };

  const response = await apiCall('/products', 'POST', newProduct);
  console.log('✅ Product added:', response.data);
}
```

#### Python
```python
def add_product():
    new_product = {
        "name": "دورة تطوير الويب المتقدمة",
        "price": 499,
        "description": "دورة شاملة تغطي React, Node.js, MongoDB",
        "cost": 100,
        "stock": 50,
        "categoryId": "cat-123",
        "sku": "WEB-COURSE-001",
        "imageUrl": "https://example.com/course.jpg",
        "isDigital": True,
        "digitalFileUrl": "https://example.com/course-files.zip"
    }

    response = requests.post(f'{BASE_URL}/products', 
                            json=new_product, 
                            headers=headers)
    print("✅ Product added:", response.json())
```

---

### 2️⃣ إنشاء كوبون خصم

#### JavaScript
```javascript
async function createCoupon() {
  const newCoupon = {
    code: "BLACKFRIDAY",
    discountType: "percentage",
    discountValue: 30,
    minPurchase: 500,
    maxUses: 1000,
    expiresAt: "2024-12-31"
  };

  const response = await apiCall('/coupons', 'POST', newCoupon);
  console.log('✅ Coupon created:', response.data);
}
```

#### Python
```python
def create_coupon():
    new_coupon = {
        "code": "BLACKFRIDAY",
        "discountType": "percentage",
        "discountValue": 30,
        "minPurchase": 500,
        "maxUses": 1000,
        "expiresAt": "2024-12-31"
    }

    response = requests.post(f'{BASE_URL}/coupons', 
                            json=new_coupon, 
                            headers=headers)
    print("✅ Coupon created:", response.json())
```

---

### 3️⃣ تحديث سعر منتج

#### JavaScript
```javascript
async function updateProductPrice(productId, newPrice) {
  const updateData = {
    price: newPrice
  };

  const response = await apiCall(`/products/${productId}`, 'PUT', updateData);
  console.log('✅ Product price updated:', response.data);
}

// الاستخدام
updateProductPrice('prod-123', 599);
```

#### Python
```python
def update_product_price(product_id, new_price):
    update_data = {
        "price": new_price
    }

    response = requests.put(f'{BASE_URL}/products/{product_id}', 
                           json=update_data, 
                           headers=headers)
    print("✅ Product price updated:", response.json())

# الاستخدام
update_product_price('prod-123', 599)
```

---

### 4️⃣ إنشاء طلب جديد (من البوت)

#### JavaScript
```javascript
async function createOrderFromBot() {
  const newOrder = {
    customerName: "محمد علي",
    customerEmail: "mohammad@example.com",
    customerPhone: "+966501234567",
    items: [
      {
        productId: "prod-1",
        quantity: 2
      },
      {
        productId: "prod-2",
        quantity: 1
      }
    ],
    notes: "تم الطلب من خلال البوت"
  };

  const response = await apiCall('/orders', 'POST', newOrder);
  console.log('✅ Order created:', response.data);
}
```

#### Python
```python
def create_order_from_bot():
    new_order = {
        "customerName": "محمد علي",
        "customerEmail": "mohammad@example.com",
        "customerPhone": "+966501234567",
        "items": [
            {
                "productId": "prod-1",
                "quantity": 2
            },
            {
                "productId": "prod-2",
                "quantity": 1
            }
        ],
        "notes": "تم الطلب من خلال البوت"
    }

    response = requests.post(f'{BASE_URL}/orders', 
                            json=new_order, 
                            headers=headers)
    print("✅ Order created:", response.json())
```

---

### 5️⃣ تحديث حالة الطلب

#### JavaScript
```javascript
async function updateOrderStatus(orderId, status) {
  const updateData = {
    status: status,
    paymentStatus: "paid"
  };

  const response = await apiCall(`/orders/${orderId}`, 'PUT', updateData);
  console.log('✅ Order status updated:', response.data);
}

// الاستخدام
updateOrderStatus('order-123', 'completed');
```

#### Python
```python
def update_order_status(order_id, status):
    update_data = {
        "status": status,
        "paymentStatus": "paid"
    }

    response = requests.put(f'{BASE_URL}/orders/{order_id}', 
                           json=update_data, 
                           headers=headers)
    print("✅ Order status updated:", response.json())

# الاستخدام
update_order_status('order-123', 'completed')
```

---

### 6️⃣ حذف منتج

#### JavaScript
```javascript
async function deleteProduct(productId) {
  const response = await apiCall(`/products/${productId}`, 'DELETE');
  console.log('✅ Product deleted:', response.message);
}
```

#### Python
```python
def delete_product(product_id):
    response = requests.delete(f'{BASE_URL}/products/{product_id}', 
                              headers=headers)
    print("✅ Product deleted:", response.json())
```

---

## 🤖 أمثلة عملية للبوتات

### 1️⃣ بوت WhatsApp

```javascript
// استخدام Twilio API مع Master API Key
const twilio = require('twilio');
const axios = require('axios');

const client = twilio(accountSid, authToken);
const API_KEY = 'your_master_api_key';
const BASE_URL = 'https://yourdomain.com/api/master';

// عند استقبال رسالة من العميل
async function handleWhatsAppMessage(from, message) {
  // إذا كان البحث عن الطلبات
  if (message.includes('طلباتي')) {
    const orders = await axios.get(`${BASE_URL}/orders`, {
      headers: { 'X-API-Key': API_KEY }
    });

    let response = 'طلباتك:\n';
    orders.data.data.orders.forEach(order => {
      response += `\n📦 الطلب: ${order.id}\nالمبلغ: ${order.finalAmount} ر.س\nالحالة: ${order.orderStatus}`;
    });

    await client.messages.create({
      from: 'whatsapp:+1234567890',
      to: `whatsapp:${from}`,
      body: response
    });
  }

  // إذا كان يريد إضافة منتج جديد
  if (message.includes('إضافة منتج')) {
    const newProduct = {
      name: "منتج جديد من البوت",
      price: 299,
      stock: 50
    };

    const result = await axios.post(`${BASE_URL}/products`, newProduct, {
      headers: { 'X-API-Key': API_KEY }
    });

    await client.messages.create({
      from: 'whatsapp:+1234567890',
      to: `whatsapp:${from}`,
      body: `✅ تم إضافة المنتج بنجاح!\nرقم المنتج: ${result.data.data.id}`
    });
  }
}
```

### 2️⃣ بوت Discord

```javascript
const { Client, Intents } = require('discord.js');
const axios = require('axios');

const client = new Client({ intents: [Intents.FLAGS.DIRECT_MESSAGES] });
const API_KEY = 'your_master_api_key';
const BASE_URL = 'https://yourdomain.com/api/master';

client.on('messageCreate', async (message) => {
  if (message.author.bot) return;

  // أمر لإضافة منتج جديد
  if (message.content.startsWith('!add-product')) {
    const args = message.content.split(' ');
    const productName = args.slice(1, -1).join(' ');
    const price = parseFloat(args[args.length - 1]);

    const newProduct = {
      name: productName,
      price: price,
      stock: 100
    };

    try {
      const result = await axios.post(`${BASE_URL}/products`, newProduct, {
        headers: { 'X-API-Key': API_KEY }
      });

      message.reply({
        embeds: [{
          title: '✅ تم إضافة المنتج',
          fields: [
            { name: 'الاسم', value: result.data.data.name },
            { name: 'السعر', value: `${result.data.data.price} ر.س` }
          ]
        }]
      });
    } catch (error) {
      message.reply('❌ حدث خطأ في إضافة المنتج');
    }
  }

  // أمر لإنشاء كوبون خصم
  if (message.content.startsWith('!create-coupon')) {
    const args = message.content.split(' ');
    const couponCode = args[1];
    const discount = parseFloat(args[2]);

    const newCoupon = {
      code: couponCode.toUpperCase(),
      discountType: "percentage",
      discountValue: discount,
      maxUses: 100
    };

    try {
      const result = await axios.post(`${BASE_URL}/coupons`, newCoupon, {
        headers: { 'X-API-Key': API_KEY }
      });

      message.reply({
        embeds: [{
          title: '✅ تم إنشاء الكوبون',
          fields: [
            { name: 'الكود', value: result.data.data.code },
            { name: 'الخصم', value: `${result.data.data.discountValue}%` }
          ]
        }]
      });
    } catch (error) {
      message.reply('❌ حدث خطأ في إنشاء الكوبون');
    }
  }
});

client.login(discordToken);
```

### 3️⃣ بوت Telegram

```javascript
const TelegramBot = require('node-telegram-bot-api');
const axios = require('axios');

const bot = new TelegramBot(telegramToken, { polling: true });
const API_KEY = 'your_master_api_key';
const BASE_URL = 'https://yourdomain.com/api/master';

// أمر /add_product
bot.onText(/\/add_product (.+) (\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const productName = match[1];
  const price = parseFloat(match[2]);

  const newProduct = {
    name: productName,
    price: price,
    stock: 100
  };

  try {
    const result = await axios.post(`${BASE_URL}/products`, newProduct, {
      headers: { 'X-API-Key': API_KEY }
    });

    bot.sendMessage(chatId, `
✅ تم إضافة المنتج بنجاح!

📦 الاسم: ${result.data.data.name}
💰 السعر: ${result.data.data.price} ر.س
🆔 رقم المنتج: ${result.data.data.id}
    `);
  } catch (error) {
    bot.sendMessage(chatId, '❌ حدث خطأ في إضافة المنتج');
  }
});

// أمر /create_coupon
bot.onText(/\/create_coupon (.+) (\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const couponCode = match[1];
  const discount = parseFloat(match[2]);

  const newCoupon = {
    code: couponCode.toUpperCase(),
    discountType: "percentage",
    discountValue: discount,
    maxUses: 100
  };

  try {
    const result = await axios.post(`${BASE_URL}/coupons`, newCoupon, {
      headers: { 'X-API-Key': API_KEY }
    });

    bot.sendMessage(chatId, `
✅ تم إنشاء الكوبون بنجاح!

🎟️ الكود: ${result.data.data.code}
📊 الخصم: ${result.data.data.discountValue}%
📅 الاستخدامات المتاحة: ${result.data.data.maxUses}
    `);
  } catch (error) {
    bot.sendMessage(chatId, '❌ حدث خطأ في إنشاء الكوبون');
  }
});
```

---

## 🔐 نصائح الأمان

1. **لا تشارك المفتاح**: لا تضع المفتاح في الكود العام
2. **استخدم متغيرات البيئة**: ضع المفتاح في ملف `.env`
3. **قم بتدوير المفاتيح**: غيّر المفاتيح بشكل دوري
4. **راقب الاستخدام**: تحقق من سجل الاستخدام في الإعدادات

---

## 📞 الدعم

إذا واجهت أي مشاكل:
- تحقق من أن المفتاح صحيح
- تأكد من أن المفتاح فعّال
- تحقق من صيغة الطلب (Request)
- راجع السجلات (Logs) للمزيد من التفاصيل

---

**تم! الآن بوتك جاهز للعمل مع كل صلاحيات المدير! 🚀🤖**
