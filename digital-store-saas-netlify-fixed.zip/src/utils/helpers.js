const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');

// Generate UUID
const generateId = () => uuidv4();

// Generate API Key
const generateApiKey = () => {
  return 'sk_' + crypto.randomBytes(32).toString('hex');
};

// Generate OTP
const generateOTP = () => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

// Create JWT Token
const createToken = (payload, expiresIn = '7d') => {
  return jwt.sign(payload, process.env.JWT_SECRET, { expiresIn });
};

// Verify JWT Token
const verifyToken = (token) => {
  try {
    return jwt.verify(token, process.env.JWT_SECRET);
  } catch (error) {
    return null;
  }
};

// Hash password
const hashPassword = async (password) => {
  const bcrypt = require('bcryptjs');
  const salt = await bcrypt.genSalt(10);
  return bcrypt.hash(password, salt);
};

// Compare password
const comparePassword = async (password, hash) => {
  const bcrypt = require('bcryptjs');
  return bcrypt.compare(password, hash);
};

// Validate email
const isValidEmail = (email) => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

// Validate phone number
const isValidPhoneNumber = (phone) => {
  const phoneRegex = /^(\+|00)[1-9]\d{1,14}$/;
  return phoneRegex.test(phone.replace(/\s/g, ''));
};

// Format currency
const formatCurrency = (amount, currency = 'SAR') => {
  return new Intl.NumberFormat('ar-SA', {
    style: 'currency',
    currency: currency,
  }).format(amount);
};

// Calculate discount
const calculateDiscount = (originalPrice, discountType, discountValue) => {
  if (discountType === 'percentage') {
    return (originalPrice * discountValue) / 100;
  } else if (discountType === 'fixed') {
    return discountValue;
  }
  return 0;
};

// Generate store slug
const generateStoreSlug = (storeName) => {
  return storeName
    .toLowerCase()
    .replace(/[^\w\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .substring(0, 50);
};

// Parse JSON safely
const safeJsonParse = (jsonString, defaultValue = {}) => {
  try {
    return JSON.parse(jsonString);
  } catch (error) {
    return defaultValue;
  }
};

// Stringify JSON safely
const safeJsonStringify = (obj, defaultValue = '{}') => {
  try {
    return JSON.stringify(obj);
  } catch (error) {
    return defaultValue;
  }
};

// Get date range
const getDateRange = (days = 30) => {
  const endDate = new Date();
  const startDate = new Date(endDate.getTime() - days * 24 * 60 * 60 * 1000);
  return { startDate, endDate };
};

// Format date
const formatDate = (date) => {
  return new Date(date).toLocaleDateString('ar-SA', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
};

module.exports = {
  generateId,
  generateApiKey,
  generateOTP,
  createToken,
  verifyToken,
  hashPassword,
  comparePassword,
  isValidEmail,
  isValidPhoneNumber,
  formatCurrency,
  calculateDiscount,
  generateStoreSlug,
  safeJsonParse,
  safeJsonStringify,
  getDateRange,
  formatDate,
};
