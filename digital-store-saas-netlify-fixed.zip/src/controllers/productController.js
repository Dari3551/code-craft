const db = require('../models/database');
const { generateId } = require('../utils/helpers');

// Get Products
const getProducts = (req, res) => {
  const { storeId } = req.params;
  const { categoryId, search, page = 1, limit = 20 } = req.query;

  try {
    let query = 'SELECT * FROM products WHERE store_id = ?';
    const params = [storeId];

    if (categoryId) {
      query += ' AND category_id = ?';
      params.push(categoryId);
    }

    if (search) {
      query += ' AND (name LIKE ? OR description LIKE ?)';
      params.push(`%${search}%`, `%${search}%`);
    }

    query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
    params.push(limit, (page - 1) * limit);

    const products = db.prepare(query).all(...params);

    res.json({ products });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch products' });
  }
};

// Get Product Details
const getProductDetails = (req, res) => {
  const { storeId, productId } = req.params;

  try {
    const product = db.prepare(`
      SELECT * FROM products WHERE id = ? AND store_id = ?
    `).get(productId, storeId);

    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }

    // Get reviews
    const reviews = db.prepare(`
      SELECT * FROM reviews WHERE product_id = ? AND is_approved = 1
      ORDER BY created_at DESC
    `).all(productId);

    res.json({ product, reviews });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
};

// Create Product
const createProduct = (req, res) => {
  const { storeId } = req.params;
  const {
    name,
    description,
    price,
    cost,
    categoryId,
    sku,
    imageUrl,
    isDigital,
    digitalFileUrl,
    stockQuantity,
  } = req.body;

  if (!name || !price) {
    return res.status(400).json({ error: 'Name and price are required' });
  }

  try {
    const productId = generateId();

    db.prepare(`
      INSERT INTO products (
        id, store_id, name, description, price, cost, category_id, sku,
        image_url, is_digital, digital_file_url, stock_quantity
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      productId,
      storeId,
      name,
      description,
      price,
      cost,
      categoryId,
      sku,
      imageUrl,
      isDigital ? 1 : 0,
      digitalFileUrl,
      stockQuantity || 0
    );

    const product = db.prepare('SELECT * FROM products WHERE id = ?').get(productId);

    res.status(201).json({
      success: true,
      message: 'Product created successfully',
      product,
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to create product' });
  }
};

// Update Product
const updateProduct = (req, res) => {
  const { storeId, productId } = req.params;
  const {
    name,
    description,
    price,
    cost,
    categoryId,
    sku,
    imageUrl,
    isDigital,
    digitalFileUrl,
    stockQuantity,
    isActive,
  } = req.body;

  try {
    const product = db.prepare(`
      SELECT * FROM products WHERE id = ? AND store_id = ?
    `).get(productId, storeId);

    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }

    db.prepare(`
      UPDATE products SET
        name = ?, description = ?, price = ?, cost = ?, category_id = ?,
        sku = ?, image_url = ?, is_digital = ?, digital_file_url = ?,
        stock_quantity = ?, is_active = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(
      name || product.name,
      description,
      price || product.price,
      cost,
      categoryId,
      sku,
      imageUrl,
      isDigital !== undefined ? (isDigital ? 1 : 0) : product.is_digital,
      digitalFileUrl,
      stockQuantity !== undefined ? stockQuantity : product.stock_quantity,
      isActive !== undefined ? (isActive ? 1 : 0) : product.is_active,
      productId
    );

    const updatedProduct = db.prepare('SELECT * FROM products WHERE id = ?').get(productId);

    res.json({
      success: true,
      message: 'Product updated successfully',
      product: updatedProduct,
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update product' });
  }
};

// Delete Product
const deleteProduct = (req, res) => {
  const { storeId, productId } = req.params;

  try {
    const product = db.prepare(`
      SELECT * FROM products WHERE id = ? AND store_id = ?
    `).get(productId, storeId);

    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }

    db.prepare('DELETE FROM products WHERE id = ?').run(productId);

    res.json({
      success: true,
      message: 'Product deleted successfully',
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete product' });
  }
};

module.exports = {
  getProducts,
  getProductDetails,
  createProduct,
  updateProduct,
  deleteProduct,
};
