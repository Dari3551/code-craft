const db = require('../models/database');
const { generateId, calculateDiscount } = require('../utils/helpers');

// Get Orders
const getOrders = (req, res) => {
  const { storeId } = req.params;
  const { status, page = 1, limit = 20 } = req.query;

  try {
    let query = 'SELECT * FROM orders WHERE store_id = ?';
    const params = [storeId];

    if (status) {
      query += ' AND status = ?';
      params.push(status);
    }

    query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
    params.push(limit, (page - 1) * limit);

    const orders = db.prepare(query).all(...params);

    res.json({ orders });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch orders' });
  }
};

// Get Order Details
const getOrderDetails = (req, res) => {
  const { storeId, orderId } = req.params;

  try {
    const order = db.prepare(`
      SELECT * FROM orders WHERE id = ? AND store_id = ?
    `).get(orderId, storeId);

    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }

    const items = db.prepare(`
      SELECT oi.*, p.name, p.image_url FROM order_items oi
      LEFT JOIN products p ON oi.product_id = p.id
      WHERE oi.order_id = ?
    `).all(orderId);

    res.json({ order, items });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
};

// Create Order
const createOrder = (req, res) => {
  const { storeId } = req.params;
  const { customerName, customerEmail, customerPhone, items, couponCode, paymentMethod, notes } = req.body;

  if (!items || items.length === 0) {
    return res.status(400).json({ error: 'Order must contain at least one item' });
  }

  try {
    const orderId = generateId();
    let totalAmount = 0;
    let discountAmount = 0;

    // Calculate total
    for (const item of items) {
      const product = db.prepare('SELECT * FROM products WHERE id = ? AND store_id = ?').get(
        item.productId,
        storeId
      );

      if (!product) {
        return res.status(400).json({ error: `Product ${item.productId} not found` });
      }

      totalAmount += product.price * item.quantity;
    }

    // Apply coupon if provided
    if (couponCode) {
      const coupon = db.prepare(`
        SELECT * FROM coupons 
        WHERE store_id = ? AND code = ? AND is_active = 1
        AND valid_from <= CURRENT_TIMESTAMP
        AND (valid_until IS NULL OR valid_until >= CURRENT_TIMESTAMP)
        AND (max_uses IS NULL OR current_uses < max_uses)
      `).get(storeId, couponCode);

      if (coupon) {
        discountAmount = calculateDiscount(totalAmount, coupon.discount_type, coupon.discount_value);
        if (discountAmount > totalAmount) {
          discountAmount = totalAmount;
        }
      }
    }

    const finalAmount = totalAmount - discountAmount;

    // Create order
    db.prepare(`
      INSERT INTO orders (
        id, store_id, customer_name, customer_email, customer_phone,
        total_amount, discount_amount, final_amount, payment_method, notes
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      orderId,
      storeId,
      customerName,
      customerEmail,
      customerPhone,
      totalAmount,
      discountAmount,
      finalAmount,
      paymentMethod,
      notes
    );

    // Add order items
    for (const item of items) {
      const product = db.prepare('SELECT * FROM products WHERE id = ?').get(item.productId);
      const itemId = generateId();

      db.prepare(`
        INSERT INTO order_items (id, order_id, product_id, quantity, unit_price, total_price)
        VALUES (?, ?, ?, ?, ?, ?)
      `).run(itemId, orderId, item.productId, item.quantity, product.price, product.price * item.quantity);

      // Update stock if not digital
      if (!product.is_digital && product.stock_quantity > 0) {
        db.prepare('UPDATE products SET stock_quantity = stock_quantity - ? WHERE id = ?').run(
          item.quantity,
          item.productId
        );
      }
    }

    // Update coupon usage if applied
    if (couponCode) {
      db.prepare('UPDATE coupons SET current_uses = current_uses + 1 WHERE code = ? AND store_id = ?').run(
        couponCode,
        storeId
      );
    }

    const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);

    res.status(201).json({
      success: true,
      message: 'Order created successfully',
      order,
    });
  } catch (error) {
    console.error('Create order error:', error);
    res.status(500).json({ error: 'Failed to create order' });
  }
};

// Update Order Status
const updateOrderStatus = (req, res) => {
  const { storeId, orderId } = req.params;
  const { status } = req.body;

  const validStatuses = ['pending', 'paid', 'completed', 'cancelled'];

  if (!validStatuses.includes(status)) {
    return res.status(400).json({ error: 'Invalid status' });
  }

  try {
    const order = db.prepare('SELECT * FROM orders WHERE id = ? AND store_id = ?').get(orderId, storeId);

    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }

    db.prepare('UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?').run(status, orderId);

    const updatedOrder = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);

    res.json({
      success: true,
      message: 'Order status updated successfully',
      order: updatedOrder,
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update order' });
  }
};

module.exports = {
  getOrders,
  getOrderDetails,
  createOrder,
  updateOrderStatus,
};
