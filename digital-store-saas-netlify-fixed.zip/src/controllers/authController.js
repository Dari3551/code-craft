// ═══════════════════════════════════════════════════════════════════════════════
// Digital Store SaaS - Authentication Controller
// نظام التحقق بـ CodeCraft Private SMS Gateway
// ═══════════════════════════════════════════════════════════════════════════════

const db = require('../models/database');
const axios = require('axios');
const {
  generateId,
  generateOTP,
  createToken,
  isValidPhoneNumber,
  hashPassword,
  comparePassword,
  generateStoreSlug,
} = require('../utils/helpers');

// ─────────────────────────────────────────────────────────────────────────────
// 📱 إرسال OTP عبر بوابة CodeCraft SMS Gateway
// ─────────────────────────────────────────────────────────────────────────────

const sendOTP = async (req, res) => {
  const { phoneNumber } = req.body;

  if (!phoneNumber || !isValidPhoneNumber(phoneNumber)) {
    return res.status(400).json({ error: 'Invalid phone number' });
  }

  try {
    // توليد OTP محلي
    const otp = generateOTP();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString(); // 10 دقائق

    // حذف جلسات OTP القديمة
    db.prepare('DELETE FROM otp_sessions WHERE phone_number = ?').run(phoneNumber);

    // إنشاء جلسة OTP جديدة
    const sessionId = generateId();
    db.prepare(`
      INSERT INTO otp_sessions (id, phone_number, otp_code, expires_at)
      VALUES (?, ?, ?, ?)
    `).run(sessionId, phoneNumber, otp, expiresAt);

    console.log(`📱 OTP generated for ${phoneNumber}: ${otp}`);

    // إرسال OTP عبر بوابة CodeCraft SMS Gateway
    if (process.env.SMS_GATEWAY_ENABLED === 'true') {
      try {
        const gatewayUrl = process.env.SMS_GATEWAY_URL;
        const gatewayKey = process.env.SMS_GATEWAY_KEY;

        const response = await axios.post(
          gatewayUrl,
          {
            number: phoneNumber,
            message: `كود التحقق لمتجر CodeCraft هو: ${otp}\nالكود صالح لمدة 10 دقائق فقط`,
            key: gatewayKey,
          },
          {
            timeout: 10000, // مهلة 10 ثوان
          }
        );

        console.log(`✅ SMS sent successfully via CodeCraft Gateway:`, response.data);
      } catch (gatewayError) {
        console.error(`⚠️ SMS Gateway Error (CodeCraft):`, gatewayError.message);
        // لا نرجع خطأ هنا - الكود تم توليده بنجاح في قاعدة البيانات
        // يمكن للمستخدم محاولة إعادة الطلب
      }
    }

    res.json({
      success: true,
      message: 'OTP sent successfully to your phone',
      sessionId,
      // For demo purposes only - remove in production
      otp: process.env.NODE_ENV === 'development' ? otp : undefined,
    });
  } catch (error) {
    console.error('Send OTP error:', error);
    res.status(500).json({
      error: 'Failed to send OTP',
      details: error.message,
    });
  }
};

// ─────────────────────────────────────────────────────────────────────────────
// ✅ التحقق من OTP (محلي - من قاعدة البيانات)
// ─────────────────────────────────────────────────────────────────────────────

const verifyOTP = async (req, res) => {
  const { phoneNumber, otp } = req.body;

  if (!phoneNumber || !otp) {
    return res.status(400).json({ error: 'Phone number and OTP are required' });
  }

  try {
    // البحث عن جلسة OTP الصحيحة
    const session = db.prepare(`
      SELECT * FROM otp_sessions 
      WHERE phone_number = ? 
      AND otp_code = ? 
      AND is_verified = 0
      AND expires_at > CURRENT_TIMESTAMP
      ORDER BY created_at DESC
      LIMIT 1
    `).get(phoneNumber, otp);

    if (!session) {
      return res.status(400).json({
        error: 'Invalid or expired OTP',
      });
    }

    // تحديث جلسة OTP - وضع علامة تحقق
    db.prepare('UPDATE otp_sessions SET is_verified = 1 WHERE id = ?').run(session.id);

    console.log(`✅ OTP verified for ${phoneNumber}`);

    // التحقق من وجود المستخدم
    let user = db.prepare('SELECT * FROM users WHERE phone_number = ?').get(phoneNumber);

    if (!user) {
      // إنشاء مستخدم جديد
      const userId = generateId();
      db.prepare(`
        INSERT INTO users (id, phone_number, is_verified, verified_at)
        VALUES (?, ?, 1, CURRENT_TIMESTAMP)
      `).run(userId, phoneNumber);

      user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);

      // إنشاء متجر افتراضي للمستخدم الجديد
      const storeId = generateId();
      const storeName = `متجري`;
      const storeSlug = generateStoreSlug(storeName) + '-' + generateId().substring(0, 6);

      db.prepare(`
        INSERT INTO stores (id, user_id, store_name, store_slug, is_active)
        VALUES (?, ?, ?, ?, 1)
      `).run(storeId, userId, storeName, storeSlug);

      console.log(`👤 New user created: ${userId} with phone: ${phoneNumber}`);
    } else {
      // تحديث حالة التحقق للمستخدم الموجود
      db.prepare(`
        UPDATE users 
        SET is_verified = 1, verified_at = CURRENT_TIMESTAMP 
        WHERE id = ?
      `).run(user.id);
    }

    // إنشاء JWT Token
    const token = createToken({
      userId: user.id,
      phoneNumber: user.phone_number,
    });

    // الحصول على متجر المستخدم
    const store = db.prepare('SELECT * FROM stores WHERE user_id = ? LIMIT 1').get(user.id);

    res.json({
      success: true,
      message: 'OTP verified successfully',
      token,
      user: {
        id: user.id,
        phoneNumber: user.phone_number,
        isVerified: user.is_verified,
      },
      store: {
        id: store?.id,
        name: store?.store_name,
        slug: store?.store_slug,
      },
    });
  } catch (error) {
    console.error('Verify OTP error:', error);
    res.status(500).json({
      error: 'Failed to verify OTP',
      details: error.message,
    });
  }
};

// ─────────────────────────────────────────────────────────────────────────────
// 👤 الحصول على بيانات المستخدم الحالي
// ─────────────────────────────────────────────────────────────────────────────

const getCurrentUser = (req, res) => {
  try {
    const userId = req.userId;

    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const store = db.prepare('SELECT * FROM stores WHERE user_id = ? LIMIT 1').get(userId);

    res.json({
      success: true,
      data: {
        user: {
          id: user.id,
          phoneNumber: user.phone_number,
          isVerified: user.is_verified,
          createdAt: user.created_at,
        },
        store: {
          id: store?.id,
          name: store?.store_name,
          slug: store?.store_slug,
          isActive: store?.is_active,
        },
      },
    });
  } catch (error) {
    console.error('Get current user error:', error);
    res.status(500).json({ error: 'Failed to get user data' });
  }
};

// ─────────────────────────────────────────────────────────────────────────────
// 🔐 تسجيل الخروج
// ─────────────────────────────────────────────────────────────────────────────

const logout = (req, res) => {
  try {
    res.json({
      success: true,
      message: 'Logged out successfully',
    });
  } catch (error) {
    console.error('Logout error:', error);
    res.status(500).json({ error: 'Failed to logout' });
  }
};

// ─────────────────────────────────────────────────────────────────────────────
// 📱 إعادة إرسال OTP
// ─────────────────────────────────────────────────────────────────────────────

const resendOTP = async (req, res) => {
  const { phoneNumber } = req.body;

  if (!phoneNumber || !isValidPhoneNumber(phoneNumber)) {
    return res.status(400).json({ error: 'Invalid phone number' });
  }

  try {
    // توليد OTP محلي جديد
    const otp = generateOTP();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString();

    // حذف جلسات OTP القديمة
    db.prepare('DELETE FROM otp_sessions WHERE phone_number = ?').run(phoneNumber);

    // إنشاء جلسة OTP جديدة
    const sessionId = generateId();
    db.prepare(`
      INSERT INTO otp_sessions (id, phone_number, otp_code, expires_at)
      VALUES (?, ?, ?, ?)
    `).run(sessionId, phoneNumber, otp, expiresAt);

    console.log(`📱 OTP resent to ${phoneNumber}: ${otp}`);

    // إرسال OTP عبر بوابة CodeCraft SMS Gateway
    if (process.env.SMS_GATEWAY_ENABLED === 'true') {
      try {
        const gatewayUrl = process.env.SMS_GATEWAY_URL;
        const gatewayKey = process.env.SMS_GATEWAY_KEY;

        const response = await axios.post(
          gatewayUrl,
          {
            number: phoneNumber,
            message: `كود التحقق الجديد لمتجر CodeCraft هو: ${otp}\nالكود صالح لمدة 10 دقائق فقط`,
            key: gatewayKey,
          },
          {
            timeout: 10000,
          }
        );

        console.log(`✅ SMS resent successfully via CodeCraft Gateway:`, response.data);
      } catch (gatewayError) {
        console.error(`⚠️ SMS Gateway Error (CodeCraft):`, gatewayError.message);
      }
    }

    res.json({
      success: true,
      message: 'OTP resent successfully',
      sessionId,
      // For demo purposes only - remove in production
      otp: process.env.NODE_ENV === 'development' ? otp : undefined,
    });
  } catch (error) {
    console.error('Resend OTP error:', error);
    res.status(500).json({
      error: 'Failed to resend OTP',
      details: error.message,
    });
  }
};

// ─────────────────────────────────────────────────────────────────────────────
// 🧪 اختبار بوابة SMS (للتطوير فقط)
// ─────────────────────────────────────────────────────────────────────────────

const testSMSGateway = async (req, res) => {
  if (process.env.NODE_ENV !== 'development') {
    return res.status(403).json({ error: 'This endpoint is only available in development mode' });
  }

  try {
    const { phoneNumber, message } = req.body;

    if (!phoneNumber || !message) {
      return res.status(400).json({ error: 'Phone number and message are required' });
    }

    const gatewayUrl = process.env.SMS_GATEWAY_URL;
    const gatewayKey = process.env.SMS_GATEWAY_KEY;

    const response = await axios.post(
      gatewayUrl,
      {
        number: phoneNumber,
        message: message,
        key: gatewayKey,
      },
      {
        timeout: 10000,
      }
    );

    res.json({
      success: true,
      message: 'Test SMS sent successfully',
      response: response.data,
    });
  } catch (error) {
    console.error('Test SMS Gateway error:', error);
    res.status(500).json({
      error: 'Failed to send test SMS',
      details: error.message,
    });
  }
};

module.exports = {
  sendOTP,
  verifyOTP,
  getCurrentUser,
  logout,
  resendOTP,
  testSMSGateway,
};
