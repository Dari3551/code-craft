const db = require('../models/database');
const { generateId, generateStoreSlug } = require('../utils/helpers');

// Get User Stores
const getUserStores = (req, res) => {
  try {
    const stores = db.prepare(`
      SELECT 
        id, user_id, store_name, store_slug, store_domain, 
        description, logo_url, currency, is_active, created_at
      FROM stores 
      WHERE user_id = ?
      ORDER BY created_at DESC
    `).all(req.user.id);

    res.json({ stores });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch stores' });
  }
};

// Get Store Details
const getStoreDetails = (req, res) => {
  try {
    const store = db.prepare('SELECT * FROM stores WHERE id = ?').get(req.params.storeId);

    if (!store) {
      return res.status(404).json({ error: 'Store not found' });
    }

    if (store.user_id !== req.user.id) {
      return res.status(403).json({ error: 'Access denied' });
    }

    res.json({ store });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
};

// Create Store
const createStore = (req, res) => {
  const { storeName, description } = req.body;

  if (!storeName) {
    return res.status(400).json({ error: 'Store name is required' });
  }

  try {
    const storeId = generateId();
    const storeSlug = generateStoreSlug(storeName) + '-' + generateId().substring(0, 6);

    db.prepare(`
      INSERT INTO stores (id, user_id, store_name, store_slug, description)
      VALUES (?, ?, ?, ?, ?)
    `).run(storeId, req.user.id, storeName, storeSlug, description || '');

    const store = db.prepare('SELECT * FROM stores WHERE id = ?').get(storeId);

    res.status(201).json({
      success: true,
      message: 'Store created successfully',
      store,
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to create store' });
  }
};

// Update Store
const updateStore = (req, res) => {
  const { storeId } = req.params;
  const { storeName, description, currency, timezone, logo_url, banner_url } = req.body;

  try {
    const store = db.prepare('SELECT * FROM stores WHERE id = ?').get(storeId);

    if (!store || store.user_id !== req.user.id) {
      return res.status(403).json({ error: 'Access denied' });
    }

    db.prepare(`
      UPDATE stores 
      SET store_name = ?, description = ?, currency = ?, timezone = ?, 
          logo_url = ?, banner_url = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(storeName || store.store_name, description, currency, timezone, logo_url, banner_url, storeId);

    const updatedStore = db.prepare('SELECT * FROM stores WHERE id = ?').get(storeId);

    res.json({
      success: true,
      message: 'Store updated successfully',
      store: updatedStore,
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update store' });
  }
};

// Get Store Statistics
const getStoreStats = (req, res) => {
  const { storeId } = req.params;

  try {
    const store = db.prepare('SELECT * FROM stores WHERE id = ?').get(storeId);

    if (!store || store.user_id !== req.user.id) {
      return res.status(403).json({ error: 'Access denied' });
    }

    // Total Revenue
    const revenueResult = db.prepare(`
      SELECT SUM(final_amount) as total_revenue
      FROM orders
      WHERE store_id = ? AND status = 'paid'
    `).get(storeId);

    // Monthly Revenue
    const monthlyResult = db.prepare(`
      SELECT SUM(final_amount) as monthly_revenue
      FROM orders
      WHERE store_id = ? AND status = 'paid'
      AND strftime('%Y-%m', created_at) = strftime('%Y-%m', 'now')
    `).get(storeId);

    // Total Orders
    const ordersResult = db.prepare(`
      SELECT COUNT(*) as total_orders FROM orders WHERE store_id = ?
    `).get(storeId);

    // Total Products
    const productsResult = db.prepare(`
      SELECT COUNT(*) as total_products FROM products WHERE store_id = ?
    `).get(storeId);

    // Total Customers
    const customersResult = db.prepare(`
      SELECT COUNT(DISTINCT customer_email) as total_customers FROM orders WHERE store_id = ?
    `).get(storeId);

    // Daily Sales (Last 30 days)
    const dailySales = db.prepare(`
      SELECT 
        DATE(created_at) as date,
        COUNT(*) as order_count,
        SUM(final_amount) as daily_revenue
      FROM orders
      WHERE store_id = ? AND status = 'paid'
      AND created_at >= datetime('now', '-30 days')
      GROUP BY DATE(created_at)
      ORDER BY date DESC
    `).all(storeId);

    // Top Products
    const topProducts = db.prepare(`
      SELECT 
        p.id, p.name, p.price,
        COUNT(oi.id) as sales_count,
        SUM(oi.total_price) as total_revenue
      FROM products p
      LEFT JOIN order_items oi ON p.id = oi.product_id
      LEFT JOIN orders o ON oi.order_id = o.id AND o.store_id = ?
      WHERE p.store_id = ?
      GROUP BY p.id
      ORDER BY sales_count DESC
      LIMIT 10
    `).all(storeId, storeId);

    res.json({
      totalRevenue: revenueResult.total_revenue || 0,
      monthlyRevenue: monthlyResult.monthly_revenue || 0,
      totalOrders: ordersResult.total_orders || 0,
      totalProducts: productsResult.total_products || 0,
      totalCustomers: customersResult.total_customers || 0,
      dailySales,
      topProducts,
    });
  } catch (error) {
    console.error('Stats error:', error);
    res.status(500).json({ error: 'Failed to fetch statistics' });
  }
};

module.exports = {
  getUserStores,
  getStoreDetails,
  createStore,
  updateStore,
  getStoreStats,
};
