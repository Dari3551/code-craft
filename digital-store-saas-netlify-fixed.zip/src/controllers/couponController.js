const db = require('../models/database');
const { generateId } = require('../utils/helpers');

// Get Coupons
const getCoupons = (req, res) => {
  const { storeId } = req.params;

  try {
    const coupons = db.prepare(`
      SELECT * FROM coupons WHERE store_id = ? ORDER BY created_at DESC
    `).all(storeId);

    res.json({ coupons });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch coupons' });
  }
};

// Create Coupon
const createCoupon = (req, res) => {
  const { storeId } = req.params;
  const { code, discountType, discountValue, minPurchase, maxUses, validFrom, validUntil } = req.body;

  if (!code || !discountType || !discountValue) {
    return res.status(400).json({ error: 'Code, discount type, and value are required' });
  }

  try {
    const couponId = generateId();

    db.prepare(`
      INSERT INTO coupons (
        id, store_id, code, discount_type, discount_value,
        min_purchase, max_uses, valid_from, valid_until
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      couponId,
      storeId,
      code.toUpperCase(),
      discountType,
      discountValue,
      minPurchase || 0,
      maxUses,
      validFrom,
      validUntil
    );

    const coupon = db.prepare('SELECT * FROM coupons WHERE id = ?').get(couponId);

    res.status(201).json({
      success: true,
      message: 'Coupon created successfully',
      coupon,
    });
  } catch (error) {
    if (error.message.includes('UNIQUE')) {
      return res.status(400).json({ error: 'Coupon code already exists' });
    }
    res.status(500).json({ error: 'Failed to create coupon' });
  }
};

// Update Coupon
const updateCoupon = (req, res) => {
  const { storeId, couponId } = req.params;
  const { code, discountType, discountValue, minPurchase, maxUses, validFrom, validUntil, isActive } = req.body;

  try {
    const coupon = db.prepare('SELECT * FROM coupons WHERE id = ? AND store_id = ?').get(couponId, storeId);

    if (!coupon) {
      return res.status(404).json({ error: 'Coupon not found' });
    }

    db.prepare(`
      UPDATE coupons SET
        code = ?, discount_type = ?, discount_value = ?,
        min_purchase = ?, max_uses = ?, valid_from = ?, valid_until = ?, is_active = ?
      WHERE id = ?
    `).run(
      code || coupon.code,
      discountType || coupon.discount_type,
      discountValue || coupon.discount_value,
      minPurchase !== undefined ? minPurchase : coupon.min_purchase,
      maxUses !== undefined ? maxUses : coupon.max_uses,
      validFrom || coupon.valid_from,
      validUntil || coupon.valid_until,
      isActive !== undefined ? (isActive ? 1 : 0) : coupon.is_active,
      couponId
    );

    const updatedCoupon = db.prepare('SELECT * FROM coupons WHERE id = ?').get(couponId);

    res.json({
      success: true,
      message: 'Coupon updated successfully',
      coupon: updatedCoupon,
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update coupon' });
  }
};

// Delete Coupon
const deleteCoupon = (req, res) => {
  const { storeId, couponId } = req.params;

  try {
    const coupon = db.prepare('SELECT * FROM coupons WHERE id = ? AND store_id = ?').get(couponId, storeId);

    if (!coupon) {
      return res.status(404).json({ error: 'Coupon not found' });
    }

    db.prepare('DELETE FROM coupons WHERE id = ?').run(couponId);

    res.json({
      success: true,
      message: 'Coupon deleted successfully',
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete coupon' });
  }
};

// Validate Coupon
const validateCoupon = (req, res) => {
  const { storeId } = req.params;
  const { code, cartTotal } = req.body;

  try {
    const coupon = db.prepare(`
      SELECT * FROM coupons 
      WHERE store_id = ? AND code = ? AND is_active = 1
      AND valid_from <= CURRENT_TIMESTAMP
      AND (valid_until IS NULL OR valid_until >= CURRENT_TIMESTAMP)
      AND (max_uses IS NULL OR current_uses < max_uses)
    `).get(storeId, code.toUpperCase());

    if (!coupon) {
      return res.status(400).json({ error: 'Invalid or expired coupon' });
    }

    if (cartTotal < coupon.min_purchase) {
      return res.status(400).json({
        error: `Minimum purchase of ${coupon.min_purchase} required`,
      });
    }

    let discount = 0;
    if (coupon.discount_type === 'percentage') {
      discount = (cartTotal * coupon.discount_value) / 100;
    } else {
      discount = coupon.discount_value;
    }

    if (discount > cartTotal) {
      discount = cartTotal;
    }

    res.json({
      success: true,
      coupon: {
        code: coupon.code,
        discountType: coupon.discount_type,
        discountValue: coupon.discount_value,
        discount,
        finalTotal: cartTotal - discount,
      },
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to validate coupon' });
  }
};

module.exports = {
  getCoupons,
  createCoupon,
  updateCoupon,
  deleteCoupon,
  validateCoupon,
};
