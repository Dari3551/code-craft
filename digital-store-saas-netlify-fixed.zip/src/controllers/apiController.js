// ═══════════════════════════════════════════════════════════════════════════════
// Digital Store SaaS - Master API Controller
// للبوتات والأنظمة الخارجية - صلاحيات المدير الكاملة
// ═══════════════════════════════════════════════════════════════════════════════

const db = require('../models/database');
const { generateId } = require('../utils/helpers');

// ─────────────────────────────────────────────────────────────────────────────
// 📊 الحصول على ملخص المتجر
// ─────────────────────────────────────────────────────────────────────────────
const getStoreSummary = (req, res) => {
  try {
    const storeId = req.storeId;

    const store = db.prepare('SELECT * FROM stores WHERE id = ?').get(storeId);
    const productsCount = db.prepare('SELECT COUNT(*) as count FROM products WHERE store_id = ?').get(storeId);
    const ordersCount = db.prepare('SELECT COUNT(*) as count FROM orders WHERE store_id = ?').get(storeId);
    const totalRevenue = db.prepare(`
      SELECT SUM(final_amount) as total FROM orders 
      WHERE store_id = ? AND payment_status = 'paid'
    `).get(storeId);
    const customersCount = db.prepare(`
      SELECT COUNT(DISTINCT customer_email) as count FROM orders WHERE store_id = ?
    `).get(storeId);

    res.json({
      success: true,
      data: {
        store: {
          id: store.id,
          name: store.store_name,
          slug: store.store_slug,
          description: store.description,
          createdAt: store.created_at,
        },
        stats: {
          productsCount: productsCount.count || 0,
          ordersCount: ordersCount.count || 0,
          totalRevenue: totalRevenue.total || 0,
          customersCount: customersCount.count || 0,
        },
      },
    });
  } catch (error) {
    console.error('Get store summary error:', error);
    res.status(500).json({ error: 'Failed to get store summary' });
  }
};

// ═══════════════════════════════════════════════════════════════════════════════
// 📦 إدارة المنتجات (CRUD)
// ═══════════════════════════════════════════════════════════════════════════════

const getAllProducts = (req, res) => {
  try {
    const storeId = req.storeId;
    const { limit = 100, offset = 0 } = req.query;

    const products = db.prepare(`
      SELECT * FROM products 
      WHERE store_id = ? 
      ORDER BY created_at DESC 
      LIMIT ? OFFSET ?
    `).all(storeId, parseInt(limit), parseInt(offset));

    const totalCount = db.prepare('SELECT COUNT(*) as count FROM products WHERE store_id = ?').get(storeId);

    res.json({
      success: true,
      data: {
        products,
        pagination: {
          total: totalCount.count,
          limit: parseInt(limit),
          offset: parseInt(offset),
        },
      },
    });
  } catch (error) {
    console.error('Get products error:', error);
    res.status(500).json({ error: 'Failed to get products' });
  }
};

const createProduct = (req, res) => {
  try {
    const storeId = req.storeId;
    const { name, description, price, cost, stock, categoryId, sku, imageUrl, isDigital, digitalFileUrl } = req.body;

    if (!name || !price) {
      return res.status(400).json({ error: 'Name and price are required' });
    }

    const productId = generateId();

    db.prepare(`
      INSERT INTO products (id, store_id, category_id, name, description, price, cost, stock, sku, image_url, is_digital, digital_file_url, is_active)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
    `).run(productId, storeId, categoryId || null, name, description || null, price, cost || 0, stock || 0, sku || null, imageUrl || null, isDigital ? 1 : 0, digitalFileUrl || null);

    const newProduct = db.prepare('SELECT * FROM products WHERE id = ?').get(productId);

    res.json({
      success: true,
      message: 'Product created successfully',
      data: newProduct,
    });
  } catch (error) {
    console.error('Create product error:', error);
    res.status(500).json({ error: 'Failed to create product' });
  }
};

const updateProduct = (req, res) => {
  try {
    const storeId = req.storeId;
    const { productId } = req.params;
    const { name, description, price, cost, stock, categoryId, sku, imageUrl, isDigital, digitalFileUrl, isActive } = req.body;

    const product = db.prepare('SELECT * FROM products WHERE id = ? AND store_id = ?').get(productId, storeId);

    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }

    db.prepare(`
      UPDATE products 
      SET name = ?, description = ?, price = ?, cost = ?, stock = ?, category_id = ?, sku = ?, image_url = ?, is_digital = ?, digital_file_url = ?, is_active = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(
      name || product.name,
      description !== undefined ? description : product.description,
      price || product.price,
      cost !== undefined ? cost : product.cost,
      stock !== undefined ? stock : product.stock,
      categoryId !== undefined ? categoryId : product.category_id,
      sku || product.sku,
      imageUrl || product.image_url,
      isDigital !== undefined ? (isDigital ? 1 : 0) : product.is_digital,
      digitalFileUrl || product.digital_file_url,
      isActive !== undefined ? (isActive ? 1 : 0) : product.is_active,
      productId
    );

    const updatedProduct = db.prepare('SELECT * FROM products WHERE id = ?').get(productId);

    res.json({
      success: true,
      message: 'Product updated successfully',
      data: updatedProduct,
    });
  } catch (error) {
    console.error('Update product error:', error);
    res.status(500).json({ error: 'Failed to update product' });
  }
};

const deleteProduct = (req, res) => {
  try {
    const storeId = req.storeId;
    const { productId } = req.params;

    const product = db.prepare('SELECT * FROM products WHERE id = ? AND store_id = ?').get(productId, storeId);

    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }

    db.prepare('DELETE FROM products WHERE id = ?').run(productId);

    res.json({
      success: true,
      message: 'Product deleted successfully',
    });
  } catch (error) {
    console.error('Delete product error:', error);
    res.status(500).json({ error: 'Failed to delete product' });
  }
};

// ═══════════════════════════════════════════════════════════════════════════════
// 🏷️ إدارة الفئات (CRUD)
// ═══════════════════════════════════════════════════════════════════════════════

const getAllCategories = (req, res) => {
  try {
    const storeId = req.storeId;

    const categories = db.prepare('SELECT * FROM categories WHERE store_id = ? ORDER BY created_at DESC').all(storeId);

    res.json({
      success: true,
      data: { categories },
    });
  } catch (error) {
    console.error('Get categories error:', error);
    res.status(500).json({ error: 'Failed to get categories' });
  }
};

const createCategory = (req, res) => {
  try {
    const storeId = req.storeId;
    const { name, description, icon } = req.body;

    if (!name) {
      return res.status(400).json({ error: 'Category name is required' });
    }

    const categoryId = generateId();

    db.prepare(`
      INSERT INTO categories (id, store_id, name, description, icon)
      VALUES (?, ?, ?, ?, ?)
    `).run(categoryId, storeId, name, description || null, icon || null);

    const newCategory = db.prepare('SELECT * FROM categories WHERE id = ?').get(categoryId);

    res.json({
      success: true,
      message: 'Category created successfully',
      data: newCategory,
    });
  } catch (error) {
    console.error('Create category error:', error);
    res.status(500).json({ error: 'Failed to create category' });
  }
};

const updateCategory = (req, res) => {
  try {
    const storeId = req.storeId;
    const { categoryId } = req.params;
    const { name, description, icon } = req.body;

    const category = db.prepare('SELECT * FROM categories WHERE id = ? AND store_id = ?').get(categoryId, storeId);

    if (!category) {
      return res.status(404).json({ error: 'Category not found' });
    }

    db.prepare(`
      UPDATE categories 
      SET name = ?, description = ?, icon = ?
      WHERE id = ?
    `).run(name || category.name, description !== undefined ? description : category.description, icon || category.icon, categoryId);

    const updatedCategory = db.prepare('SELECT * FROM categories WHERE id = ?').get(categoryId);

    res.json({
      success: true,
      message: 'Category updated successfully',
      data: updatedCategory,
    });
  } catch (error) {
    console.error('Update category error:', error);
    res.status(500).json({ error: 'Failed to update category' });
  }
};

const deleteCategory = (req, res) => {
  try {
    const storeId = req.storeId;
    const { categoryId } = req.params;

    const category = db.prepare('SELECT * FROM categories WHERE id = ? AND store_id = ?').get(categoryId, storeId);

    if (!category) {
      return res.status(404).json({ error: 'Category not found' });
    }

    db.prepare('DELETE FROM categories WHERE id = ?').run(categoryId);

    res.json({
      success: true,
      message: 'Category deleted successfully',
    });
  } catch (error) {
    console.error('Delete category error:', error);
    res.status(500).json({ error: 'Failed to delete category' });
  }
};

// ═══════════════════════════════════════════════════════════════════════════════
// 🎟️ إدارة الكوبونات (CRUD)
// ═══════════════════════════════════════════════════════════════════════════════

const getAllCoupons = (req, res) => {
  try {
    const storeId = req.storeId;

    const coupons = db.prepare('SELECT * FROM coupons WHERE store_id = ? ORDER BY created_at DESC').all(storeId);

    res.json({
      success: true,
      data: { coupons },
    });
  } catch (error) {
    console.error('Get coupons error:', error);
    res.status(500).json({ error: 'Failed to get coupons' });
  }
};

const createCoupon = (req, res) => {
  try {
    const storeId = req.storeId;
    const { code, discountType, discountValue, minPurchase, maxUses, expiresAt } = req.body;

    if (!code || !discountType || !discountValue) {
      return res.status(400).json({ error: 'Code, discount type, and discount value are required' });
    }

    const couponId = generateId();

    db.prepare(`
      INSERT INTO coupons (id, store_id, code, discount_type, discount_value, min_purchase, max_uses, expires_at, is_active)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
    `).run(couponId, storeId, code.toUpperCase(), discountType, discountValue, minPurchase || 0, maxUses || null, expiresAt || null);

    const newCoupon = db.prepare('SELECT * FROM coupons WHERE id = ?').get(couponId);

    res.json({
      success: true,
      message: 'Coupon created successfully',
      data: newCoupon,
    });
  } catch (error) {
    console.error('Create coupon error:', error);
    res.status(500).json({ error: 'Failed to create coupon' });
  }
};

const updateCoupon = (req, res) => {
  try {
    const storeId = req.storeId;
    const { couponId } = req.params;
    const { code, discountType, discountValue, minPurchase, maxUses, expiresAt, isActive } = req.body;

    const coupon = db.prepare('SELECT * FROM coupons WHERE id = ? AND store_id = ?').get(couponId, storeId);

    if (!coupon) {
      return res.status(404).json({ error: 'Coupon not found' });
    }

    db.prepare(`
      UPDATE coupons 
      SET code = ?, discount_type = ?, discount_value = ?, min_purchase = ?, max_uses = ?, expires_at = ?, is_active = ?
      WHERE id = ?
    `).run(
      code ? code.toUpperCase() : coupon.code,
      discountType || coupon.discount_type,
      discountValue !== undefined ? discountValue : coupon.discount_value,
      minPurchase !== undefined ? minPurchase : coupon.min_purchase,
      maxUses !== undefined ? maxUses : coupon.max_uses,
      expiresAt !== undefined ? expiresAt : coupon.expires_at,
      isActive !== undefined ? (isActive ? 1 : 0) : coupon.is_active,
      couponId
    );

    const updatedCoupon = db.prepare('SELECT * FROM coupons WHERE id = ?').get(couponId);

    res.json({
      success: true,
      message: 'Coupon updated successfully',
      data: updatedCoupon,
    });
  } catch (error) {
    console.error('Update coupon error:', error);
    res.status(500).json({ error: 'Failed to update coupon' });
  }
};

const deleteCoupon = (req, res) => {
  try {
    const storeId = req.storeId;
    const { couponId } = req.params;

    const coupon = db.prepare('SELECT * FROM coupons WHERE id = ? AND store_id = ?').get(couponId, storeId);

    if (!coupon) {
      return res.status(404).json({ error: 'Coupon not found' });
    }

    db.prepare('DELETE FROM coupons WHERE id = ?').run(couponId);

    res.json({
      success: true,
      message: 'Coupon deleted successfully',
    });
  } catch (error) {
    console.error('Delete coupon error:', error);
    res.status(500).json({ error: 'Failed to delete coupon' });
  }
};

// ═══════════════════════════════════════════════════════════════════════════════
// 📋 إدارة الطلبات
// ═══════════════════════════════════════════════════════════════════════════════

const getAllOrders = (req, res) => {
  try {
    const storeId = req.storeId;
    const { status, limit = 100, offset = 0 } = req.query;

    let query = 'SELECT * FROM orders WHERE store_id = ?';
    const params = [storeId];

    if (status) {
      query += ' AND order_status = ?';
      params.push(status);
    }

    query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    const orders = db.prepare(query).all(...params);

    const ordersWithItems = orders.map(order => {
      const items = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(order.id);
      return { ...order, items };
    });

    const totalCount = db.prepare('SELECT COUNT(*) as count FROM orders WHERE store_id = ?').get(storeId);

    res.json({
      success: true,
      data: {
        orders: ordersWithItems,
        pagination: {
          total: totalCount.count,
          limit: parseInt(limit),
          offset: parseInt(offset),
        },
      },
    });
  } catch (error) {
    console.error('Get orders error:', error);
    res.status(500).json({ error: 'Failed to get orders' });
  }
};

const createOrder = (req, res) => {
  try {
    const { customerName, customerEmail, customerPhone, items, notes } = req.body;
    const storeId = req.storeId;

    if (!customerName || !items || items.length === 0) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const orderId = generateId();
    let totalAmount = 0;

    for (const item of items) {
      const product = db.prepare('SELECT * FROM products WHERE id = ? AND store_id = ?').get(item.productId, storeId);
      
      if (!product) {
        return res.status(404).json({ error: `Product ${item.productId} not found` });
      }

      totalAmount += product.price * item.quantity;
    }

    db.prepare(`
      INSERT INTO orders (id, store_id, customer_name, customer_email, customer_phone, total_amount, final_amount, notes)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(orderId, storeId, customerName, customerEmail, customerPhone, totalAmount, totalAmount, notes);

    for (const item of items) {
      const product = db.prepare('SELECT * FROM products WHERE id = ?').get(item.productId);
      
      db.prepare(`
        INSERT INTO order_items (id, order_id, product_id, quantity, price)
        VALUES (?, ?, ?, ?, ?)
      `).run(generateId(), orderId, item.productId, item.quantity, product.price);
    }

    const newOrder = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);

    res.json({
      success: true,
      message: 'Order created successfully',
      data: newOrder,
    });
  } catch (error) {
    console.error('Create order error:', error);
    res.status(500).json({ error: 'Failed to create order' });
  }
};

const updateOrderStatus = (req, res) => {
  try {
    const { orderId } = req.params;
    const { status, paymentStatus } = req.body;
    const storeId = req.storeId;

    const order = db.prepare('SELECT * FROM orders WHERE id = ? AND store_id = ?').get(orderId, storeId);

    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }

    db.prepare(`
      UPDATE orders 
      SET order_status = ?, payment_status = ?, updated_at = CURRENT_TIMESTAMP 
      WHERE id = ?
    `).run(status || order.order_status, paymentStatus || order.payment_status, orderId);

    const updatedOrder = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);

    res.json({
      success: true,
      message: 'Order updated successfully',
      data: updatedOrder,
    });
  } catch (error) {
    console.error('Update order error:', error);
    res.status(500).json({ error: 'Failed to update order' });
  }
};

const deleteOrder = (req, res) => {
  try {
    const storeId = req.storeId;
    const { orderId } = req.params;

    const order = db.prepare('SELECT * FROM orders WHERE id = ? AND store_id = ?').get(orderId, storeId);

    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }

    db.prepare('DELETE FROM order_items WHERE order_id = ?').run(orderId);
    db.prepare('DELETE FROM orders WHERE id = ?').run(orderId);

    res.json({
      success: true,
      message: 'Order deleted successfully',
    });
  } catch (error) {
    console.error('Delete order error:', error);
    res.status(500).json({ error: 'Failed to delete order' });
  }
};

// ═══════════════════════════════════════════════════════════════════════════════
// 👥 إدارة العملاء
// ═══════════════════════════════════════════════════════════════════════════════

const getAllCustomers = (req, res) => {
  try {
    const storeId = req.storeId;

    const customers = db.prepare(`
      SELECT DISTINCT 
        customer_email,
        customer_name,
        customer_phone,
        COUNT(*) as orders_count,
        SUM(final_amount) as total_spent,
        MAX(created_at) as last_order_date
      FROM orders 
      WHERE store_id = ? 
      GROUP BY customer_email, customer_name, customer_phone
      ORDER BY total_spent DESC
    `).all(storeId);

    res.json({
      success: true,
      data: {
        customers,
        total: customers.length,
      },
    });
  } catch (error) {
    console.error('Get customers error:', error);
    res.status(500).json({ error: 'Failed to get customers' });
  }
};

// ═══════════════════════════════════════════════════════════════════════════════
// 💰 الإحصائيات المالية
// ═══════════════════════════════════════════════════════════════════════════════

const getFinancialStats = (req, res) => {
  try {
    const storeId = req.storeId;

    const totalRevenue = db.prepare(`
      SELECT SUM(final_amount) as total FROM orders 
      WHERE store_id = ? AND payment_status = 'paid'
    `).get(storeId);

    const dailyRevenue = db.prepare(`
      SELECT 
        DATE(created_at) as date,
        SUM(final_amount) as revenue,
        COUNT(*) as orders_count
      FROM orders 
      WHERE store_id = ? AND payment_status = 'paid'
      AND created_at >= datetime('now', '-30 days')
      GROUP BY DATE(created_at)
      ORDER BY date DESC
    `).all(storeId);

    const topProducts = db.prepare(`
      SELECT 
        p.id,
        p.name,
        p.price,
        COUNT(oi.id) as sales_count,
        SUM(oi.quantity) as total_quantity,
        SUM(oi.quantity * oi.price) as total_revenue
      FROM products p
      LEFT JOIN order_items oi ON p.id = oi.product_id
      LEFT JOIN orders o ON oi.order_id = o.id
      WHERE p.store_id = ?
      GROUP BY p.id, p.name, p.price
      ORDER BY total_revenue DESC
      LIMIT 10
    `).all(storeId);

    res.json({
      success: true,
      data: {
        totalRevenue: totalRevenue.total || 0,
        dailyRevenue,
        topProducts,
      },
    });
  } catch (error) {
    console.error('Get financial stats error:', error);
    res.status(500).json({ error: 'Failed to get financial stats' });
  }
};

// ═══════════════════════════════════════════════════════════════════════════════
// 🔍 البحث
// ═══════════════════════════════════════════════════════════════════════════════

const search = (req, res) => {
  try {
    const { query: searchQuery, type } = req.query;
    const storeId = req.storeId;

    if (!searchQuery) {
      return res.status(400).json({ error: 'Search query is required' });
    }

    let results = {};

    if (!type || type === 'products') {
      results.products = db.prepare(`
        SELECT * FROM products 
        WHERE store_id = ? AND (name LIKE ? OR description LIKE ?)
        LIMIT 10
      `).all(storeId, `%${searchQuery}%`, `%${searchQuery}%`);
    }

    if (!type || type === 'orders') {
      results.orders = db.prepare(`
        SELECT * FROM orders 
        WHERE store_id = ? AND (customer_name LIKE ? OR customer_email LIKE ? OR id LIKE ?)
        LIMIT 10
      `).all(storeId, `%${searchQuery}%`, `%${searchQuery}%`, `%${searchQuery}%`);
    }

    if (!type || type === 'customers') {
      results.customers = db.prepare(`
        SELECT DISTINCT customer_email, customer_name, customer_phone
        FROM orders 
        WHERE store_id = ? AND (customer_name LIKE ? OR customer_email LIKE ?)
        LIMIT 10
      `).all(storeId, `%${searchQuery}%`, `%${searchQuery}%`);
    }

    res.json({
      success: true,
      data: results,
    });
  } catch (error) {
    console.error('Search error:', error);
    res.status(500).json({ error: 'Failed to search' });
  }
};

module.exports = {
  getStoreSummary,
  getAllProducts,
  createProduct,
  updateProduct,
  deleteProduct,
  getAllCategories,
  createCategory,
  updateCategory,
  deleteCategory,
  getAllCoupons,
  createCoupon,
  updateCoupon,
  deleteCoupon,
  getAllOrders,
  createOrder,
  updateOrderStatus,
  deleteOrder,
  getAllCustomers,
  getFinancialStats,
  search,
};
