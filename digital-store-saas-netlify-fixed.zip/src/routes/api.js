const express = require('express');
const router = express.Router();
const db = require('../models/database');
const { verifyJWT } = require('../middleware/auth');
const { generateId, generateApiKey } = require('../utils/helpers');

// Get API Keys
router.get('/:storeId', verifyJWT, (req, res) => {
  const { storeId } = req.params;

  try {
    const store = db.prepare('SELECT * FROM stores WHERE id = ? AND user_id = ?').get(storeId, req.user.id);

    if (!store) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const keys = db.prepare(`
      SELECT id, name, key, permissions, is_active, last_used, created_at
      FROM api_keys
      WHERE store_id = ?
      ORDER BY created_at DESC
    `).all(storeId);

    res.json({ keys });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch API keys' });
  }
});

// Create API Key
router.post('/:storeId', verifyJWT, (req, res) => {
  const { storeId } = req.params;
  const { name, permissions } = req.body;

  try {
    const store = db.prepare('SELECT * FROM stores WHERE id = ? AND user_id = ?').get(storeId, req.user.id);

    if (!store) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const keyId = generateId();
    const apiKey = generateApiKey();

    db.prepare(`
      INSERT INTO api_keys (id, store_id, key, name, permissions)
      VALUES (?, ?, ?, ?, ?)
    `).run(keyId, storeId, apiKey, name, JSON.stringify(permissions || []));

    res.status(201).json({
      success: true,
      message: 'API key created successfully',
      key: {
        id: keyId,
        name,
        key: apiKey,
        permissions,
      },
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to create API key' });
  }
});

// Delete API Key
router.delete('/:storeId/:keyId', verifyJWT, (req, res) => {
  const { storeId, keyId } = req.params;

  try {
    const store = db.prepare('SELECT * FROM stores WHERE id = ? AND user_id = ?').get(storeId, req.user.id);

    if (!store) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const key = db.prepare('SELECT * FROM api_keys WHERE id = ? AND store_id = ?').get(keyId, storeId);

    if (!key) {
      return res.status(404).json({ error: 'API key not found' });
    }

    db.prepare('DELETE FROM api_keys WHERE id = ?').run(keyId);

    res.json({
      success: true,
      message: 'API key deleted successfully',
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete API key' });
  }
});

module.exports = router;
