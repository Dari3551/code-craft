const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const { verifyJWT } = require('../middleware/auth');

// Send OTP
router.post('/send-otp', authController.sendOTP);

// Verify OTP
router.post('/verify-otp', authController.verifyOTP);

// Get Current User
router.get('/me', verifyJWT, authController.getCurrentUser);

// Update Profile
router.put('/profile', verifyJWT, authController.updateUserProfile);

module.exports = router;
