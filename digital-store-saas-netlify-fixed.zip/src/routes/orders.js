const express = require('express');
const router = express.Router();
const orderController = require('../controllers/orderController');
const { verifyJWT, optionalAuth } = require('../middleware/auth');

// Get Orders (Admin)
router.get('/:storeId', verifyJWT, orderController.getOrders);

// Get Order Details (Admin)
router.get('/:storeId/:orderId', verifyJWT, orderController.getOrderDetails);

// Create Order (Public)
router.post('/:storeId', optionalAuth, orderController.createOrder);

// Update Order Status (Admin)
router.put('/:storeId/:orderId', verifyJWT, orderController.updateOrderStatus);

module.exports = router;
