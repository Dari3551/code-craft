const express = require('express');
const router = express.Router();
const couponController = require('../controllers/couponController');
const { verifyJWT, optionalAuth } = require('../middleware/auth');

// Get Coupons (Admin)
router.get('/:storeId', verifyJWT, couponController.getCoupons);

// Create Coupon (Admin)
router.post('/:storeId', verifyJWT, couponController.createCoupon);

// Update Coupon (Admin)
router.put('/:storeId/:couponId', verifyJWT, couponController.updateCoupon);

// Delete Coupon (Admin)
router.delete('/:storeId/:couponId', verifyJWT, couponController.deleteCoupon);

// Validate Coupon (Public)
router.post('/:storeId/validate', optionalAuth, couponController.validateCoupon);

module.exports = router;
