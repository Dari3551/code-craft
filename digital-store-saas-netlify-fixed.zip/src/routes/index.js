const express = require('express');
const router = express.Router();

// Auth Routes
const authRoutes = require('./auth');
router.use('/auth', authRoutes);

// Store Routes
const storeRoutes = require('./stores');
router.use('/stores', storeRoutes);

// Product Routes
const productRoutes = require('./products');
router.use('/products', productRoutes);

// Order Routes
const orderRoutes = require('./orders');
router.use('/orders', orderRoutes);

// Coupon Routes
const couponRoutes = require('./coupons');
router.use('/coupons', couponRoutes);

// API Routes
const apiRoutes = require('./api');
router.use('/api-keys', apiRoutes);

// Webhook Routes
const webhookRoutes = require('./webhooks');
router.use('/webhooks', webhookRoutes);

// Master API Routes (For Bots & External Systems)
const masterApiRoutes = require('./master-api');
router.use('/master', masterApiRoutes);

module.exports = router;
