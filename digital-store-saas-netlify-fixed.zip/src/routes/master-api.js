// ═══════════════════════════════════════════════════════════════════════════════
// Digital Store SaaS - Master API Routes
// للبوتات والأنظمة الخارجية - صلاحيات المدير الكاملة
// ═══════════════════════════════════════════════════════════════════════════════

const express = require('express');
const router = express.Router();
const { verifyMasterApiKey } = require('../middleware/auth');
const apiController = require('../controllers/apiController');

// ─────────────────────────────────────────────────────────────────────────────
// 🔐 جميع الـ endpoints تتطلب Master API Key
// ─────────────────────────────────────────────────────────────────────────────

// 📊 ملخص المتجر
router.get('/summary', verifyMasterApiKey, apiController.getStoreSummary);

// ═══════════════════════════════════════════════════════════════════════════════
// 📦 إدارة المنتجات
// ═══════════════════════════════════════════════════════════════════════════════
router.get('/products', verifyMasterApiKey, apiController.getAllProducts);
router.post('/products', verifyMasterApiKey, apiController.createProduct);
router.put('/products/:productId', verifyMasterApiKey, apiController.updateProduct);
router.delete('/products/:productId', verifyMasterApiKey, apiController.deleteProduct);

// ═══════════════════════════════════════════════════════════════════════════════
// 🏷️ إدارة الفئات
// ═══════════════════════════════════════════════════════════════════════════════
router.get('/categories', verifyMasterApiKey, apiController.getAllCategories);
router.post('/categories', verifyMasterApiKey, apiController.createCategory);
router.put('/categories/:categoryId', verifyMasterApiKey, apiController.updateCategory);
router.delete('/categories/:categoryId', verifyMasterApiKey, apiController.deleteCategory);

// ═══════════════════════════════════════════════════════════════════════════════
// 🎟️ إدارة الكوبونات
// ═══════════════════════════════════════════════════════════════════════════════
router.get('/coupons', verifyMasterApiKey, apiController.getAllCoupons);
router.post('/coupons', verifyMasterApiKey, apiController.createCoupon);
router.put('/coupons/:couponId', verifyMasterApiKey, apiController.updateCoupon);
router.delete('/coupons/:couponId', verifyMasterApiKey, apiController.deleteCoupon);

// ═══════════════════════════════════════════════════════════════════════════════
// 📋 إدارة الطلبات
// ═══════════════════════════════════════════════════════════════════════════════
router.get('/orders', verifyMasterApiKey, apiController.getAllOrders);
router.post('/orders', verifyMasterApiKey, apiController.createOrder);
router.put('/orders/:orderId', verifyMasterApiKey, apiController.updateOrderStatus);
router.delete('/orders/:orderId', verifyMasterApiKey, apiController.deleteOrder);

// ═══════════════════════════════════════════════════════════════════════════════
// 👥 إدارة العملاء
// ═══════════════════════════════════════════════════════════════════════════════
router.get('/customers', verifyMasterApiKey, apiController.getAllCustomers);

// ═══════════════════════════════════════════════════════════════════════════════
// 💰 الإحصائيات المالية
// ═══════════════════════════════════════════════════════════════════════════════
router.get('/stats/financial', verifyMasterApiKey, apiController.getFinancialStats);

// ═══════════════════════════════════════════════════════════════════════════════
// 🔍 البحث
// ═══════════════════════════════════════════════════════════════════════════════
router.get('/search', verifyMasterApiKey, apiController.search);

module.exports = router;
