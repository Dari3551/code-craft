const express = require('express');
const router = express.Router();
const storeController = require('../controllers/storeController');
const { verifyJWT, verifyStoreAccess } = require('../middleware/auth');

// Get User Stores
router.get('/', verifyJWT, storeController.getUserStores);

// Create Store
router.post('/', verifyJWT, storeController.createStore);

// Get Store Details
router.get('/:storeId', verifyJWT, storeController.getStoreDetails);

// Update Store
router.put('/:storeId', verifyJWT, storeController.updateStore);

// Get Store Statistics
router.get('/:storeId/stats', verifyJWT, storeController.getStoreStats);

module.exports = router;
