const express = require('express');
const router = express.Router();
const db = require('../models/database');
const { verifyJWT } = require('../middleware/auth');
const { generateId } = require('../utils/helpers');
const axios = require('axios');

// Get Webhooks
router.get('/:storeId', verifyJWT, (req, res) => {
  const { storeId } = req.params;

  try {
    const store = db.prepare('SELECT * FROM stores WHERE id = ? AND user_id = ?').get(storeId, req.user.id);

    if (!store) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const webhooks = db.prepare(`
      SELECT id, url, events, is_active, created_at FROM webhooks WHERE store_id = ?
      ORDER BY created_at DESC
    `).all(storeId);

    res.json({ webhooks });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch webhooks' });
  }
});

// Create Webhook
router.post('/:storeId', verifyJWT, (req, res) => {
  const { storeId } = req.params;
  const { url, events } = req.body;

  if (!url || !events || events.length === 0) {
    return res.status(400).json({ error: 'URL and events are required' });
  }

  try {
    const store = db.prepare('SELECT * FROM stores WHERE id = ? AND user_id = ?').get(storeId, req.user.id);

    if (!store) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const webhookId = generateId();
    const secret = require('crypto').randomBytes(32).toString('hex');

    db.prepare(`
      INSERT INTO webhooks (id, store_id, url, events, secret)
      VALUES (?, ?, ?, ?, ?)
    `).run(webhookId, storeId, url, JSON.stringify(events), secret);

    res.status(201).json({
      success: true,
      message: 'Webhook created successfully',
      webhook: {
        id: webhookId,
        url,
        events,
        secret,
      },
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to create webhook' });
  }
});

// Delete Webhook
router.delete('/:storeId/:webhookId', verifyJWT, (req, res) => {
  const { storeId, webhookId } = req.params;

  try {
    const store = db.prepare('SELECT * FROM stores WHERE id = ? AND user_id = ?').get(storeId, req.user.id);

    if (!store) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const webhook = db.prepare('SELECT * FROM webhooks WHERE id = ? AND store_id = ?').get(webhookId, storeId);

    if (!webhook) {
      return res.status(404).json({ error: 'Webhook not found' });
    }

    db.prepare('DELETE FROM webhooks WHERE id = ?').run(webhookId);

    res.json({
      success: true,
      message: 'Webhook deleted successfully',
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete webhook' });
  }
});

// Trigger Webhook
async function triggerWebhook(storeId, event, data) {
  try {
    const webhooks = db.prepare(`
      SELECT * FROM webhooks WHERE store_id = ? AND is_active = 1
    `).all(storeId);

    for (const webhook of webhooks) {
      const events = JSON.parse(webhook.events || '[]');
      if (events.includes(event)) {
        try {
          await axios.post(webhook.url, {
            event,
            data,
            timestamp: new Date().toISOString(),
          });
        } catch (error) {
          console.error(`Webhook trigger failed for ${webhook.url}:`, error.message);
        }
      }
    }
  } catch (error) {
    console.error('Trigger webhook error:', error);
  }
}

module.exports = router;
module.exports.triggerWebhook = triggerWebhook;
