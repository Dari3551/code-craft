const express = require('express');
const router = express.Router();
const productController = require('../controllers/productController');
const { verifyJWT, verifyStoreAccess } = require('../middleware/auth');

// Get Products
router.get('/:storeId', verifyJWT, productController.getProducts);

// Get Product Details
router.get('/:storeId/:productId', verifyJWT, productController.getProductDetails);

// Create Product
router.post('/:storeId', verifyJWT, productController.createProduct);

// Update Product
router.put('/:storeId/:productId', verifyJWT, productController.updateProduct);

// Delete Product
router.delete('/:storeId/:productId', verifyJWT, productController.deleteProduct);

module.exports = router;
