const { verifyToken } = require('../utils/helpers');
const db = require('../models/database');

// Verify JWT Token
const verifyJWT = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ error: 'No token provided' });
  }

  const decoded = verifyToken(token);
  if (!decoded) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }

  req.user = decoded;
  next();
};

// Verify Store Access
const verifyStoreAccess = (req, res, next) => {
  const storeId = req.params.storeId || req.body.storeId;
  
  if (!storeId) {
    return res.status(400).json({ error: 'Store ID is required' });
  }

  try {
    const store = db.prepare('SELECT * FROM stores WHERE id = ?').get(storeId);
    
    if (!store) {
      return res.status(404).json({ error: 'Store not found' });
    }

    if (store.user_id !== req.user.id) {
      return res.status(403).json({ error: 'Access denied' });
    }

    req.store = store;
    next();
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
};

// ═══════════════════════════════════════════════════════════════════════════════
// 🔑 Verify Master API Key - للبوتات والأنظمة الخارجية
// ═══════════════════════════════════════════════════════════════════════════════
const verifyMasterApiKey = (req, res, next) => {
  const apiKey = req.headers['x-api-key'] || req.headers['x-master-key'];
  
  if (!apiKey) {
    return res.status(401).json({ error: 'API key is required' });
  }

  try {
    // البحث عن المفتاح في قاعدة البيانات
    const keyRecord = db.prepare(`
      SELECT * FROM api_keys 
      WHERE key_value = ? AND is_active = 1
    `).get(apiKey);
    
    if (!keyRecord) {
      return res.status(401).json({ error: 'Invalid API key' });
    }

    // التحقق من أن المفتاح لم ينتهِ
    if (keyRecord.expires_at && new Date(keyRecord.expires_at) < new Date()) {
      return res.status(401).json({ error: 'API key expired' });
    }

    // الحصول على بيانات المتجر
    const store = db.prepare('SELECT * FROM stores WHERE id = ?').get(keyRecord.store_id);
    
    if (!store) {
      return res.status(404).json({ error: 'Store not found' });
    }

    // تحديث آخر استخدام
    db.prepare('UPDATE api_keys SET last_used_at = CURRENT_TIMESTAMP WHERE id = ?').run(keyRecord.id);

    // إضافة بيانات المفتاح والمتجر إلى الطلب
    req.store = store;
    req.storeId = store.id;
    req.apiKey = keyRecord;
    req.authType = 'master-api-key';
    
    // إعطاء صلاحيات كاملة
    req.permissions = ['read', 'write', 'delete', 'admin'];
    
    next();
  } catch (error) {
    console.error('Master API Key verification error:', error);
    res.status(500).json({ error: 'Server error' });
  }
};

// Verify API Key (الطريقة القديمة - للتوافق)
const verifyApiKey = (req, res, next) => {
  const apiKey = req.headers['x-api-key'];
  
  if (!apiKey) {
    return res.status(401).json({ error: 'API key is required' });
  }

  try {
    const keyRecord = db.prepare('SELECT * FROM api_keys WHERE key = ? AND is_active = 1').get(apiKey);
    
    if (!keyRecord) {
      return res.status(401).json({ error: 'Invalid API key' });
    }

    // Update last used
    db.prepare('UPDATE api_keys SET last_used = CURRENT_TIMESTAMP WHERE id = ?').run(keyRecord.id);

    req.store = db.prepare('SELECT * FROM stores WHERE id = ?').get(keyRecord.store_id);
    req.apiKey = keyRecord;
    next();
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
};

// Optional Auth (for public endpoints)
const optionalAuth = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  
  if (token) {
    const decoded = verifyToken(token);
    if (decoded) {
      req.user = decoded;
    }
  }
  
  next();
};

module.exports = {
  verifyJWT,
  verifyStoreAccess,
  verifyMasterApiKey,
  verifyApiKey,
  optionalAuth,
};
