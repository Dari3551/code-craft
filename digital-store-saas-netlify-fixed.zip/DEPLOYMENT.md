# 🚀 دليل النشر - Digital Store SaaS Platform

## المتطلبات قبل النشر

- Node.js 14+
- npm أو yarn
- حساب Stripe (للدفع)
- حساب Twilio (لـ OTP)
- خادم ويب (Heroku, DigitalOcean, AWS, إلخ)

## 1️⃣ النشر على Heroku

### الخطوات:

```bash
# تثبيت Heroku CLI
# https://devcenter.heroku.com/articles/heroku-cli

# تسجيل الدخول
heroku login

# إنشاء تطبيق جديد
heroku create your-app-name

# إضافة متغيرات البيئة
heroku config:set NODE_ENV=production
heroku config:set JWT_SECRET=your_super_secret_key
heroku config:set STRIPE_SECRET_KEY=sk_live_your_key
heroku config:set TWILIO_ACCOUNT_SID=your_sid
heroku config:set TWILIO_AUTH_TOKEN=your_token

# نشر التطبيق
git push heroku main

# عرض السجلات
heroku logs --tail
```

## 2️⃣ النشر على DigitalOcean

### الخطوات:

```bash
# 1. إنشاء Droplet
# - اختر Ubuntu 22.04
# - حجم: 2GB RAM على الأقل

# 2. الاتصال بالـ Droplet
ssh root@your_droplet_ip

# 3. تثبيت Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# 4. تثبيت PM2 (لتشغيل التطبيق)
sudo npm install -g pm2

# 5. استنساخ المشروع
git clone your-repo-url
cd digital-store-saas

# 6. تثبيت المكتبات
npm install

# 7. إعداد متغيرات البيئة
nano .env
# أضف المتغيرات المطلوبة

# 8. تشغيل التطبيق مع PM2
pm2 start server.js --name "digital-store"
pm2 startup
pm2 save

# 9. إعداد Nginx (اختياري)
sudo apt-get install nginx
# إنشاء ملف إعدادات Nginx
```

## 3️⃣ النشر على AWS

### الخطوات:

```bash
# 1. إنشاء EC2 Instance
# - اختر Ubuntu 22.04
# - حجم: t3.small على الأقل

# 2. الاتصال بالـ Instance
ssh -i your-key.pem ubuntu@your-instance-ip

# 3. تحديث النظام
sudo apt update && sudo apt upgrade -y

# 4. تثبيت Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# 5. تثبيت PM2
sudo npm install -g pm2

# 6. استنساخ المشروع
git clone your-repo-url
cd digital-store-saas

# 7. تثبيت المكتبات
npm install

# 8. إعداد متغيرات البيئة
nano .env

# 9. تشغيل التطبيق
pm2 start server.js --name "digital-store"

# 10. إعداد RDS (قاعدة البيانات)
# استخدم Amazon RDS لـ MySQL بدلاً من SQLite
```

## 4️⃣ النشر على Railway

```bash
# 1. تثبيت Railway CLI
npm i -g @railway/cli

# 2. تسجيل الدخول
railway login

# 3. إنشاء مشروع جديد
railway init

# 4. ربط المشروع
railway link

# 5. إضافة متغيرات البيئة
railway variables

# 6. النشر
railway up
```

## 5️⃣ النشر على Render

```bash
# 1. ربط مستودع GitHub الخاص بك

# 2. إنشاء Web Service جديد على Render

# 3. إعدادات الخدمة:
# - Build Command: npm install
# - Start Command: npm start
# - Environment: Node

# 4. إضافة متغيرات البيئة في لوحة التحكم

# 5. النشر تلقائياً عند كل push
```

## 📊 إعدادات الإنتاج

### تحسين الأداء:

```javascript
// استخدم Redis للـ Cache
npm install redis

// استخدم قاعدة بيانات احترافية
// MySQL بدلاً من SQLite
npm install mysql2
```

### الأمان:

1. **استخدم HTTPS**
   ```bash
   # استخدم Let's Encrypt
   sudo apt-get install certbot python3-certbot-nginx
   sudo certbot certonly --nginx -d your-domain.com
   ```

2. **تحديث متغيرات البيئة**
   - غيّر `JWT_SECRET` إلى قيمة قوية
   - استخدم مفاتيح Stripe و Twilio الحقيقية

3. **تفعيل Rate Limiting**
   - تم تفعيله بالفعل في `server.js`

4. **استخدم Helmet.js**
   - تم تفعيله بالفعل

### المراقبة:

```bash
# استخدم PM2 Plus للمراقبة
pm2 plus

# أو استخدم New Relic
npm install newrelic
```

## 🔄 التحديثات والصيانة

### تحديث التطبيق:

```bash
# سحب التحديثات الجديدة
git pull origin main

# تثبيت المكتبات الجديدة
npm install

# إعادة تشغيل التطبيق
pm2 restart digital-store
```

### النسخ الاحتياطية:

```bash
# نسخ احتياطية يومية لقاعدة البيانات
0 2 * * * /path/to/backup-script.sh
```

## 🐛 استكشاف الأخطاء

### عرض السجلات:

```bash
# PM2
pm2 logs digital-store

# Heroku
heroku logs --tail

# DigitalOcean
journalctl -u digital-store -f
```

### مشاكل شائعة:

1. **خطأ في الاتصال بقاعدة البيانات**
   - تحقق من متغيرات البيئة
   - تأكد من إذنيات الملفات

2. **خطأ في OTP**
   - تحقق من بيانات Twilio
   - تأكد من رقم الهاتف الصحيح

3. **خطأ في الدفع**
   - تحقق من مفاتيح Stripe
   - استخدم بطاقات اختبار Stripe

## 📞 الدعم

للمزيد من المساعدة:
- [Heroku Docs](https://devcenter.heroku.com/)
- [DigitalOcean Docs](https://docs.digitalocean.com/)
- [AWS Docs](https://docs.aws.amazon.com/)
- [Express.js Docs](https://expressjs.com/)

---

**نصيحة:** ابدأ بـ Heroku أو Railway للتطوير السريع، ثم انتقل إلى DigitalOcean أو AWS للإنتاج.
