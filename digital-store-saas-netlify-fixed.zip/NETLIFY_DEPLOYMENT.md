# 🚀 دليل نشر منصة Digital Store SaaS على Netlify

هذا الدليل يشرح كيفية نشر المنصة على **Netlify** باستخدام **Serverless Functions**.

---

## 📋 المتطلبات

- حساب على [Netlify](https://netlify.com)
- حساب على [GitHub](https://github.com) (اختياري - لكن موصى به)
- Node.js و npm مثبتة على جهازك

---

## 🔧 الخطوة 1: تحضير المشروع محلياً

### 1. استخرج ملف ZIP
```bash
unzip digital-store-saas-codecraft-gateway.zip
cd digital-store-saas
```

### 2. ثبت المكتبات
```bash
npm install
```

### 3. تحقق من ملف `.env`
تأكد من أن ملف `.env` يحتوي على جميع المتغيرات المطلوبة:
```env
NODE_ENV=production
PORT=3001
DATABASE_URL=postgresql://...
SMS_GATEWAY_URL=https://elementary-democrat-despite-kent.trycloudflare.com/send-otp
SMS_GATEWAY_KEY=CODE_CRAFT_SECURE_2026
SMS_GATEWAY_ENABLED=true
```

---

## 📤 الخطوة 2: رفع المشروع إلى GitHub

### 1. أنشئ مستودع جديد على GitHub
```bash
git init
git add .
git commit -m "Initial commit: Digital Store SaaS for Netlify"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/digital-store-saas.git
git push -u origin main
```

---

## 🌐 الخطوة 3: ربط المشروع بـ Netlify

### الطريقة 1: عبر واجهة Netlify (الأسهل)

1. اذهب إلى [Netlify Dashboard](https://app.netlify.com)
2. اضغط على **"Add new site"** > **"Import an existing project"**
3. اختر **GitHub** وسجل دخولك
4. اختر المستودع `digital-store-saas`
5. اضغط **"Deploy site"**

### الطريقة 2: عبر Netlify CLI

```bash
# تثبيت Netlify CLI
npm install -g netlify-cli

# تسجيل الدخول
netlify login

# نشر المشروع
netlify deploy --prod
```

---

## ⚙️ الخطوة 4: تكوين متغيرات البيئة على Netlify

1. اذهب إلى **Site Settings** > **Build & Deploy** > **Environment**
2. اضغط **"Edit variables"**
3. أضف المتغيرات التالية:

```
NODE_ENV = production
DATABASE_URL = postgresql://...
SMS_GATEWAY_URL = https://elementary-democrat-despite-kent.trycloudflare.com/send-otp
SMS_GATEWAY_KEY = CODE_CRAFT_SECURE_2026
SMS_GATEWAY_ENABLED = true
JWT_SECRET = your_super_secret_key_here
STRIPE_SECRET_KEY = sk_test_...
TWILIO_ACCOUNT_SID = AC...
TWILIO_AUTH_TOKEN = ...
```

---

## 🏗️ الخطوة 5: تكوين Build Settings

1. اذهب إلى **Site Settings** > **Build & Deploy** > **Build settings**
2. تأكد من الإعدادات التالية:

| الإعداد | القيمة |
|--------|--------|
| **Build command** | `npm run build` |
| **Publish directory** | `public` |
| **Functions directory** | `netlify/functions` |
| **Node version** | 18.x أو أعلى |

---

## 🔍 الخطوة 6: التحقق من النشر

### 1. تحقق من الـ Build Logs
- اذهب إلى **Deploys** > آخر نشر
- تحقق من أن البناء اكتمل بنجاح

### 2. اختبر الـ API
```bash
# اختبر Health Check
curl https://your-site-name.netlify.app/api/health

# يجب أن تحصل على:
{
  "status": "ok",
  "timestamp": "2024-...",
  "environment": "production",
  "platform": "Netlify Serverless"
}
```

### 3. اختبر إرسال OTP
```bash
curl -X POST https://your-site-name.netlify.app/api/auth/send-otp \
  -H "Content-Type: application/json" \
  -d '{"phoneNumber": "+966554986089"}'
```

---

## 🛠️ استكشاف الأخطاء

### المشكلة: "Function not found"
**الحل:** تأكد من أن ملف `netlify/functions/server.js` موجود

### المشكلة: "Database connection error"
**الحل:** تحقق من متغير `DATABASE_URL` في إعدادات Netlify

### المشكلة: "CORS error"
**الحل:** تأكد من أن `netlify.toml` يحتوي على رؤوس CORS الصحيحة

### المشكلة: "SMS Gateway timeout"
**الحل:** تحقق من أن رابط `SMS_GATEWAY_URL` صحيح وأن البوابة تعمل

---

## 📊 مراقبة الأداء

### عرض السجلات (Logs)
```bash
netlify logs
```

### عرض استخدام الدوال (Functions)
اذهب إلى **Analytics** > **Functions** لرؤية عدد استدعاءات الدوال والأخطاء

---

## 🔐 الأمان

### 1. استخدم متغيرات البيئة
- لا تضع المفاتيح الحساسة في الكود
- استخدم متغيرات البيئة فقط

### 2. فعّل HTTPS
- Netlify يفعّل HTTPS تلقائياً

### 3. استخدم نطاق مخصص
1. اذهب إلى **Site settings** > **Domain management**
2. أضف نطاقك المخصص

---

## 🚀 النشر المستمر (CI/CD)

Netlify يدعم النشر المستمر تلقائياً:
- كل دفع (push) إلى `main` سيؤدي إلى نشر تلقائي
- يمكنك إعداد **Deploy Previews** للـ Pull Requests

---

## 📝 ملفات مهمة

| الملف | الوصف |
|------|-------|
| `netlify.toml` | تكوين Netlify |
| `netlify/functions/server.js` | دالة Serverless الرئيسية |
| `package.json` | المكتبات والـ Scripts |
| `.env` | متغيرات البيئة |

---

## 💡 نصائح مهمة

1. **استخدم Netlify Functions**: لا تحاول تشغيل سيرفر تقليدي
2. **قاعدة البيانات**: استخدم Supabase أو قاعدة بيانات سحابية
3. **التخزين**: استخدم AWS S3 أو Cloudinary للملفات
4. **الأداء**: راقب استخدام الدوال وحدود Netlify

---

## 📞 الدعم

- [Netlify Documentation](https://docs.netlify.com)
- [Netlify Functions Guide](https://docs.netlify.com/functions/overview)
- [Serverless HTTP Documentation](https://github.com/dougmoscrop/serverless-http)

---

**تم! المنصة الآن جاهزة للعمل على Netlify! 🎉**
