/* ═══════════════════════════════════════════════════════════
   Digital Store SaaS - Storefront Script
═══════════════════════════════════════════════════════════ */

const API_BASE = '/api';
let cart = [];
let currentStore = null;
let appliedCoupon = null;

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  loadStore();
  loadProducts();
  setupPaymentMethodListener();
});

// ─── Store Functions ────────────────────────────────────────
async function loadStore() {
  const storeSlug = getStoreSlugFromURL();
  
  try {
    // In a real app, you'd fetch store by slug
    // For now, we'll use a demo store
    currentStore = {
      id: 'demo-store',
      store_name: 'متجري الرائع',
      description: 'متجر متخصص في بيع المنتجات الرقمية',
    };

    document.getElementById('storeName').textContent = currentStore.store_name;
    document.getElementById('heroTitle').textContent = `مرحباً بك في ${currentStore.store_name}`;
    document.getElementById('heroDesc').textContent = currentStore.description;
  } catch (error) {
    console.error('Failed to load store:', error);
  }
}

function getStoreSlugFromURL() {
  // Extract store slug from URL (e.g., store-name.platform.com)
  const hostname = window.location.hostname;
  const parts = hostname.split('.');
  return parts[0] !== 'www' ? parts[0] : 'default';
}

// ─── Products Functions ────────────────────────────────────
async function loadProducts() {
  if (!currentStore) return;

  try {
    // Demo products
    const products = [
      {
        id: '1',
        name: 'دورة تطوير الويب',
        description: 'تعلم تطوير الويب من الصفر إلى الاحتراف',
        price: 299,
        image: '📚',
        isDigital: true,
      },
      {
        id: '2',
        name: 'قالب متجر إلكتروني',
        description: 'قالب احترافي لمتجرك الإلكتروني',
        price: 199,
        image: '🎨',
        isDigital: true,
      },
      {
        id: '3',
        name: 'كتاب تعلم JavaScript',
        description: 'كتاب شامل لتعلم لغة JavaScript',
        price: 99,
        image: '📖',
        isDigital: true,
      },
      {
        id: '4',
        name: 'استشارة تقنية',
        description: 'جلسة استشارة تقنية مع خبير',
        price: 500,
        image: '💼',
        isDigital: true,
      },
    ];

    displayProducts(products);
  } catch (error) {
    console.error('Failed to load products:', error);
  }
}

function displayProducts(products) {
  const grid = document.getElementById('productsGrid');
  
  grid.innerHTML = products.map(product => `
    <div class="product-card">
      <div class="product-image">${product.image}</div>
      <div class="product-info">
        <h3 class="product-name">${product.name}</h3>
        <p class="product-description">${product.description}</p>
        <div class="product-price">${formatCurrency(product.price)}</div>
        <div class="product-actions">
          <button class="btn btn-primary" onclick="addToCart('${product.id}', '${product.name}', ${product.price})">
            <i class="fas fa-shopping-cart"></i> إضافة للسلة
          </button>
        </div>
      </div>
    </div>
  `).join('');
}

// ─── Cart Functions ────────────────────────────────────────
function addToCart(productId, productName, price) {
  const existingItem = cart.find(item => item.id === productId);
  
  if (existingItem) {
    existingItem.quantity += 1;
  } else {
    cart.push({
      id: productId,
      name: productName,
      price: price,
      quantity: 1,
    });
  }

  updateCart();
  toggleCart();
}

function updateCart() {
  const cartItemsDiv = document.getElementById('cartItems');
  const cartCountBadge = document.getElementById('cartCount');
  const cartTotalSpan = document.getElementById('cartTotal');

  cartCountBadge.textContent = cart.reduce((sum, item) => sum + item.quantity, 0);

  if (cart.length === 0) {
    cartItemsDiv.innerHTML = '<p class="text-center">السلة فارغة</p>';
    cartTotalSpan.textContent = '0 ر.س';
    return;
  }

  const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  cartTotalSpan.textContent = formatCurrency(total);

  cartItemsDiv.innerHTML = cart.map(item => `
    <div class="cart-item">
      <div class="cart-item-image">📦</div>
      <div class="cart-item-info">
        <div class="cart-item-name">${item.name}</div>
        <div class="cart-item-price">${formatCurrency(item.price)}</div>
        <div class="cart-item-quantity">
          <button class="quantity-btn" onclick="updateQuantity('${item.id}', -1)">-</button>
          <span>${item.quantity}</span>
          <button class="quantity-btn" onclick="updateQuantity('${item.id}', 1)">+</button>
          <button class="quantity-btn" onclick="removeFromCart('${item.id}')" style="background: #fee2e2; color: #dc2626;">
            <i class="fas fa-trash"></i>
          </button>
        </div>
      </div>
    </div>
  `).join('');
}

function updateQuantity(productId, change) {
  const item = cart.find(i => i.id === productId);
  if (item) {
    item.quantity += change;
    if (item.quantity <= 0) {
      removeFromCart(productId);
    } else {
      updateCart();
    }
  }
}

function removeFromCart(productId) {
  cart = cart.filter(item => item.id !== productId);
  updateCart();
}

function toggleCart() {
  document.getElementById('cartSidebar').classList.toggle('hidden');
}

// ─── Coupon Functions ───────────────────────────────────────
async function applyCoupon() {
  const couponCode = document.getElementById('couponCode').value;
  
  if (!couponCode) {
    alert('أدخل كود الخصم');
    return;
  }

  const cartTotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  try {
    const response = await fetch(`${API_BASE}/coupons/${currentStore.id}/validate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code: couponCode, cartTotal }),
    });

    const data = await response.json();

    if (response.ok) {
      appliedCoupon = data.coupon;
      showDiscountInfo();
      alert('تم تطبيق الكود بنجاح');
    } else {
      alert('خطأ: ' + data.error);
    }
  } catch (error) {
    alert('فشل في التحقق من الكود');
  }
}

function showDiscountInfo() {
  const discountInfo = document.getElementById('discountInfo');
  const discountAmount = document.getElementById('discountAmount');
  const finalTotal = document.getElementById('finalTotal');
  const cartTotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  discountAmount.textContent = formatCurrency(appliedCoupon.discount);
  finalTotal.textContent = formatCurrency(appliedCoupon.finalTotal);
  discountInfo.classList.remove('hidden');
}

// ─── Checkout Functions ─────────────────────────────────────
function goToCheckout() {
  if (cart.length === 0) {
    alert('السلة فارغة');
    return;
  }

  document.getElementById('cartSidebar').classList.add('hidden');
  document.getElementById('productsGrid').parentElement.parentElement.classList.add('hidden');
  document.getElementById('checkoutPage').classList.remove('hidden');

  updateCheckoutSummary();
}

function updateCheckoutSummary() {
  const orderItems = document.getElementById('orderItems');
  const summaryTotal = document.getElementById('summaryTotal');
  const cartTotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const finalTotal = appliedCoupon ? appliedCoupon.finalTotal : cartTotal;

  orderItems.innerHTML = cart.map(item => `
    <div class="order-item">
      <span>${item.name} × ${item.quantity}</span>
      <span>${formatCurrency(item.price * item.quantity)}</span>
    </div>
  `).join('');

  if (appliedCoupon) {
    orderItems.innerHTML += `
      <div class="order-item">
        <span>الخصم</span>
        <span>-${formatCurrency(appliedCoupon.discount)}</span>
      </div>
    `;
  }

  summaryTotal.textContent = formatCurrency(finalTotal);
}

function setupPaymentMethodListener() {
  const paymentMethods = document.querySelectorAll('input[name="paymentMethod"]');
  paymentMethods.forEach(method => {
    method.addEventListener('change', (e) => {
      const bankDetails = document.getElementById('bankTransferDetails');
      if (e.target.value === 'bank_transfer') {
        bankDetails.classList.remove('hidden');
      } else {
        bankDetails.classList.add('hidden');
      }
    });
  });
}

async function handleCheckout(e) {
  e.preventDefault();

  const customerName = document.getElementById('customerName').value;
  const customerEmail = document.getElementById('customerEmail').value;
  const customerPhone = document.getElementById('customerPhone').value;
  const paymentMethod = document.querySelector('input[name="paymentMethod"]:checked').value;
  const notes = document.getElementById('orderNotes').value;

  const orderData = {
    customerName,
    customerEmail,
    customerPhone,
    paymentMethod,
    notes,
    items: cart,
    couponCode: appliedCoupon ? appliedCoupon.code : null,
  };

  try {
    const response = await fetch(`${API_BASE}/orders/${currentStore.id}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(orderData),
    });

    const data = await response.json();

    if (response.ok) {
      showSuccessPage(data.order.id);
      cart = [];
      appliedCoupon = null;
    } else {
      alert('خطأ: ' + data.error);
    }
  } catch (error) {
    alert('فشل في إتمام الطلب');
  }
}

function showSuccessPage(orderId) {
  document.getElementById('checkoutPage').classList.add('hidden');
  document.getElementById('successPage').classList.remove('hidden');
  document.getElementById('orderNumber').textContent = orderId.substring(0, 8);
}

function backToCart() {
  document.getElementById('checkoutPage').classList.add('hidden');
  document.getElementById('productsGrid').parentElement.parentElement.classList.remove('hidden');
}

function backToHome() {
  document.getElementById('successPage').classList.add('hidden');
  document.getElementById('productsGrid').parentElement.parentElement.classList.remove('hidden');
  updateCart();
}

// ─── Utility Functions ──────────────────────────────────────
function formatCurrency(amount) {
  return new Intl.NumberFormat('ar-SA', {
    style: 'currency',
    currency: 'SAR',
  }).format(amount);
}
