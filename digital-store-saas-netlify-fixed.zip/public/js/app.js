/* ═══════════════════════════════════════════════════════════
   Digital Store SaaS - Main Application Script
═══════════════════════════════════════════════════════════ */

const API_BASE = '/api';
let currentUser = null;
let currentStore = null;
let sessionId = null;

// Initialize App
document.addEventListener('DOMContentLoaded', () => {
  const token = localStorage.getItem('token');
  
  if (token) {
    loadDashboard();
  } else {
    showAuthScreen();
  }
});

// ─── Auth Functions ─────────────────────────────────────────
async function handleSendOTP(e) {
  e.preventDefault();
  const phone = document.getElementById('phoneInput').value;

  try {
    const response = await fetch(`${API_BASE}/auth/send-otp`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phoneNumber: phone }),
    });

    const data = await response.json();

    if (response.ok) {
      sessionId = data.sessionId;
      document.getElementById('otpForm').classList.add('hidden');
      document.getElementById('otpVerify').classList.remove('hidden');
      
      // For demo - show OTP
      if (data.otp) {
        console.log('Demo OTP:', data.otp);
      }
    } else {
      alert('خطأ: ' + data.error);
    }
  } catch (error) {
    alert('فشل في إرسال الكود');
  }
}

async function handleVerifyOTP(e) {
  e.preventDefault();
  const phone = document.getElementById('phoneInput').value;
  const otp = document.getElementById('otpInput').value;

  try {
    const response = await fetch(`${API_BASE}/auth/verify-otp`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phoneNumber: phone, otp }),
    });

    const data = await response.json();

    if (response.ok) {
      localStorage.setItem('token', data.token);
      currentUser = data.user;
      loadDashboard();
    } else {
      alert('خطأ: ' + data.error);
    }
  } catch (error) {
    alert('فشل في التحقق من الكود');
  }
}

function backToPhone() {
  document.getElementById('otpForm').classList.remove('hidden');
  document.getElementById('otpVerify').classList.add('hidden');
}

function handleLogout() {
  localStorage.removeItem('token');
  currentUser = null;
  currentStore = null;
  showAuthScreen();
}

// ─── Dashboard Functions ────────────────────────────────────
async function loadDashboard() {
  document.getElementById('authScreen').classList.add('hidden');
  document.getElementById('dashboardScreen').classList.remove('hidden');
  document.getElementById('loading').classList.add('hidden');

  // Load user info
  const userResponse = await fetch(`${API_BASE}/auth/me`, {
    headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` },
  });

  if (userResponse.ok) {
    currentUser = await userResponse.json();
    document.getElementById('userName').textContent = currentUser.name || currentUser.phoneNumber;
  }

  // Load stores
  const storesResponse = await fetch(`${API_BASE}/stores`, {
    headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` },
  });

  if (storesResponse.ok) {
    const data = await storesResponse.json();
    if (data.stores.length > 0) {
      currentStore = data.stores[0];
      loadDashboardData();
    }
  }
}

async function loadDashboardData() {
  if (!currentStore) return;

  try {
    const response = await fetch(`${API_BASE}/stores/${currentStore.id}/stats`, {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` },
    });

    const stats = await response.json();

    // Update stat cards
    document.getElementById('totalRevenue').textContent = formatCurrency(stats.totalRevenue);
    document.getElementById('monthlyRevenue').textContent = formatCurrency(stats.monthlyRevenue);
    document.getElementById('totalOrders').textContent = stats.totalOrders;
    document.getElementById('totalCustomers').textContent = stats.totalCustomers;

    // Draw charts
    drawCharts(stats);
  } catch (error) {
    console.error('Failed to load dashboard data:', error);
  }
}

function drawCharts(stats) {
  // Daily Sales Chart
  const dailySalesCtx = document.getElementById('dailySalesChart');
  if (dailySalesCtx && stats.dailySales) {
    new Chart(dailySalesCtx, {
      type: 'line',
      data: {
        labels: stats.dailySales.map(d => d.date),
        datasets: [{
          label: 'المبيعات اليومية',
          data: stats.dailySales.map(d => d.daily_revenue),
          borderColor: '#6366f1',
          backgroundColor: 'rgba(99, 102, 241, 0.1)',
          tension: 0.4,
          fill: true,
        }],
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: true },
        },
        scales: {
          y: { beginAtZero: true },
        },
      },
    });
  }

  // Top Products Chart
  const topProductsCtx = document.getElementById('topProductsChart');
  if (topProductsCtx && stats.topProducts) {
    new Chart(topProductsCtx, {
      type: 'bar',
      data: {
        labels: stats.topProducts.map(p => p.name),
        datasets: [{
          label: 'عدد المبيعات',
          data: stats.topProducts.map(p => p.sales_count),
          backgroundColor: '#6366f1',
        }],
      },
      options: {
        responsive: true,
        indexAxis: 'y',
        plugins: {
          legend: { display: false },
        },
      },
    });
  }
}

// ─── Page Navigation ────────────────────────────────────────
function showPage(pageName) {
  // Hide all pages
  document.querySelectorAll('.page').forEach(page => {
    page.classList.add('hidden');
  });

  // Show selected page
  document.getElementById(pageName + 'Page').classList.remove('hidden');

  // Update title
  const titles = {
    dashboard: 'لوحة التحكم',
    products: 'المنتجات',
    orders: 'الطلبات',
    coupons: 'أكواد الخصم',
    customers: 'العملاء',
    settings: 'الإعدادات',
  };
  document.getElementById('pageTitle').textContent = titles[pageName] || 'الصفحة';

  // Update nav
  document.querySelectorAll('.nav-item').forEach(item => {
    item.classList.remove('active');
  });
  event.target.closest('.nav-item').classList.add('active');

  // Load page data
  if (pageName === 'products') loadProducts();
  if (pageName === 'orders') loadOrders();
  if (pageName === 'coupons') loadCoupons();
  if (pageName === 'settings') loadSettings();
}

// ─── Products ───────────────────────────────────────────────
async function loadProducts() {
  if (!currentStore) return;

  try {
    const response = await fetch(`${API_BASE}/products/${currentStore.id}`, {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` },
    });

    const data = await response.json();
    const list = document.getElementById('productsList');

    if (data.products.length === 0) {
      list.innerHTML = '<p class="text-center">لا توجد منتجات</p>';
      return;
    }

    list.innerHTML = data.products.map(product => `
      <div class="product-card">
        <div class="product-image">📦</div>
        <div class="product-info">
          <div class="product-name">${product.name}</div>
          <div class="product-price">${formatCurrency(product.price)}</div>
          <div class="product-actions">
            <button class="edit" onclick="editProduct('${product.id}')">تعديل</button>
            <button class="delete" onclick="deleteProduct('${product.id}')">حذف</button>
          </div>
        </div>
      </div>
    `).join('');
  } catch (error) {
    console.error('Failed to load products:', error);
  }
}

function openProductModal() {
  document.getElementById('productModal').classList.remove('hidden');
}

async function handleAddProduct(e) {
  e.preventDefault();

  const product = {
    name: document.getElementById('productName').value,
    description: document.getElementById('productDescription').value,
    price: parseFloat(document.getElementById('productPrice').value),
    stockQuantity: parseInt(document.getElementById('productStock').value),
  };

  try {
    const response = await fetch(`${API_BASE}/products/${currentStore.id}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`,
      },
      body: JSON.stringify(product),
    });

    if (response.ok) {
      closeModal('productModal');
      loadProducts();
      alert('تم إضافة المنتج بنجاح');
    }
  } catch (error) {
    alert('فشل في إضافة المنتج');
  }
}

// ─── Orders ─────────────────────────────────────────────────
async function loadOrders() {
  if (!currentStore) return;

  try {
    const response = await fetch(`${API_BASE}/orders/${currentStore.id}`, {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` },
    });

    const data = await response.json();
    const list = document.getElementById('ordersList');

    if (data.orders.length === 0) {
      list.innerHTML = '<p class="text-center">لا توجد طلبات</p>';
      return;
    }

    list.innerHTML = `
      <div class="order-row" style="font-weight: bold; background: #f9fafb;">
        <div>رقم الطلب</div>
        <div>العميل</div>
        <div>المبلغ</div>
        <div>التاريخ</div>
        <div>الحالة</div>
      </div>
      ${data.orders.map(order => `
        <div class="order-row">
          <div class="order-id">#${order.id.substring(0, 8)}</div>
          <div>${order.customer_name}</div>
          <div>${formatCurrency(order.final_amount)}</div>
          <div>${new Date(order.created_at).toLocaleDateString('ar-SA')}</div>
          <div class="order-status ${order.status}">${getStatusLabel(order.status)}</div>
        </div>
      `).join('')}
    `;
  } catch (error) {
    console.error('Failed to load orders:', error);
  }
}

// ─── Coupons ────────────────────────────────────────────────
async function loadCoupons() {
  if (!currentStore) return;

  try {
    const response = await fetch(`${API_BASE}/coupons/${currentStore.id}`, {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` },
    });

    const data = await response.json();
    const list = document.getElementById('couponsList');

    if (data.coupons.length === 0) {
      list.innerHTML = '<p class="text-center">لا توجد أكواد خصم</p>';
      return;
    }

    list.innerHTML = data.coupons.map(coupon => `
      <div class="product-card">
        <div class="product-info">
          <div class="product-name">${coupon.code}</div>
          <div class="product-price">${coupon.discount_type === 'percentage' ? coupon.discount_value + '%' : formatCurrency(coupon.discount_value)}</div>
          <div class="product-actions">
            <button class="delete" onclick="deleteCoupon('${coupon.id}')">حذف</button>
          </div>
        </div>
      </div>
    `).join('');
  } catch (error) {
    console.error('Failed to load coupons:', error);
  }
}

function openCouponModal() {
  document.getElementById('couponModal').classList.remove('hidden');
}

async function handleAddCoupon(e) {
  e.preventDefault();

  const coupon = {
    code: document.getElementById('couponCode').value,
    discountType: document.getElementById('discountType').value,
    discountValue: parseFloat(document.getElementById('discountValue').value),
  };

  try {
    const response = await fetch(`${API_BASE}/coupons/${currentStore.id}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`,
      },
      body: JSON.stringify(coupon),
    });

    if (response.ok) {
      closeModal('couponModal');
      loadCoupons();
      alert('تم إضافة الكود بنجاح');
    }
  } catch (error) {
    alert('فشل في إضافة الكود');
  }
}

// ─── Settings ───────────────────────────────────────────────
function loadSettings() {
  if (!currentStore) return;

  document.getElementById('storeName').value = currentStore.store_name;
  document.getElementById('storeDescription').value = currentStore.description || '';
}

async function handleUpdateStore(e) {
  e.preventDefault();

  const store = {
    storeName: document.getElementById('storeName').value,
    description: document.getElementById('storeDescription').value,
  };

  try {
    const response = await fetch(`${API_BASE}/stores/${currentStore.id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`,
      },
      body: JSON.stringify(store),
    });

    if (response.ok) {
      alert('تم تحديث المتجر بنجاح');
    }
  } catch (error) {
    alert('فشل في تحديث المتجر');
  }
}

// ─── Utility Functions ──────────────────────────────────────
function showAuthScreen() {
  document.getElementById('loading').classList.add('hidden');
  document.getElementById('authScreen').classList.remove('hidden');
  document.getElementById('dashboardScreen').classList.add('hidden');
}

function formatCurrency(amount) {
  return new Intl.NumberFormat('ar-SA', {
    style: 'currency',
    currency: 'SAR',
  }).format(amount);
}

function getStatusLabel(status) {
  const labels = {
    pending: 'قيد الانتظار',
    paid: 'مدفوع',
    completed: 'مكتمل',
    cancelled: 'ملغى',
  };
  return labels[status] || status;
}

function closeModal(modalId) {
  document.getElementById(modalId).classList.add('hidden');
}

function toggleSidebar() {
  document.querySelector('.sidebar').classList.toggle('open');
}

function showSettingsTab(tab) {
  document.querySelectorAll('.settings-tab').forEach(t => t.classList.add('hidden'));
  document.getElementById(tab + 'Settings').classList.remove('hidden');

  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  event.target.classList.add('active');
}

async function deleteCoupon(couponId) {
  if (!confirm('هل تريد حذف هذا الكود؟')) return;

  try {
    const response = await fetch(`${API_BASE}/coupons/${currentStore.id}/${couponId}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` },
    });

    if (response.ok) {
      loadCoupons();
      alert('تم حذف الكود بنجاح');
    }
  } catch (error) {
    alert('فشل في حذف الكود');
  }
}

async function deleteProduct(productId) {
  if (!confirm('هل تريد حذف هذا المنتج؟')) return;

  try {
    const response = await fetch(`${API_BASE}/products/${currentStore.id}/${productId}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` },
    });

    if (response.ok) {
      loadProducts();
      alert('تم حذف المنتج بنجاح');
    }
  } catch (error) {
    alert('فشل في حذف المنتج');
  }
}

async function generateAPIKey() {
  const name = prompt('أدخل اسم المفتاح:');
  if (!name) return;

  try {
    const response = await fetch(`${API_BASE}/api-keys/${currentStore.id}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`,
      },
      body: JSON.stringify({ name, permissions: ['read', 'write'] }),
    });

    if (response.ok) {
      const data = await response.json();
      alert('تم إنشاء المفتاح:\n' + data.key.key);
    }
  } catch (error) {
    alert('فشل في إنشاء المفتاح');
  }
}
