# Digital Store SaaS Platform

منصة متكاملة لإنشاء المتاجر الرقمية (Shopify/Chaptr Style)

## 🚀 المميزات الرئيسية

### ✅ نظام المصادقة
- تسجيل دخول عبر OTP (SMS)
- إنشاء حساب تلقائي للمستخدمين الجدد
- JWT Token للمصادقة الآمنة

### ✅ إدارة المتاجر
- إنشاء متاجر متعددة لكل مستخدم
- رابط تلقائي للمتجر (store-slug.platform.com)
- تخصيص الدومين

### ✅ إدارة المنتجات
- إضافة/تعديل/حذف المنتجات
- دعم المنتجات الرقمية
- تصنيفات المنتجات
- إدارة المخزون

### ✅ إدارة الطلبات
- عرض جميع الطلبات
- تحديث حالة الطلب (Pending/Paid/Completed/Cancelled)
- تفاصيل الطلب والعميل

### ✅ أكواد الخصم
- إنشاء أكواد خصم
- نسبة مئوية أو مبلغ ثابت
- حد أدنى للشراء
- عدد استخدام محدود
- تاريخ انتهاء الصلاحية

### ✅ التحليلات المتقدمة
- إجمالي الأرباح
- الأرباح الشهرية
- عدد الطلبات والعملاء
- رسوم بيانية للمبيعات اليومية
- أكثر المنتجات مبيعاً

### ✅ نظام الدفع
- Stripe Integration
- Apple Pay
- Mada/Visa/MasterCard
- تحويل بنكي
- تفعيل/تعطيل طرق الدفع

### ✅ API متكامل
- `/api/auth` - المصادقة
- `/api/stores` - إدارة المتاجر
- `/api/products` - إدارة المنتجات
- `/api/orders` - إدارة الطلبات
- `/api/coupons` - أكواد الخصم
- `/api/api-keys` - مفاتيح API
- `/api/webhooks` - الـ Webhooks

### ✅ Webhooks
- إنشاء Webhooks مخصصة
- أحداث مدعومة:
  - order.created
  - order.paid
  - user.created
  - product.created

### ✅ الأمان
- JWT Authentication
- Rate Limiting
- Helmet.js
- CORS
- Input Validation

## 📋 المتطلبات

- Node.js 14+
- npm أو yarn
- SQLite3

## 🛠️ التثبيت والتشغيل

### 1. تثبيت المكتبات
```bash
npm install
```

### 2. إعداد متغيرات البيئة
```bash
cp .env.example .env
```

ثم عدّل `.env` بالقيم الخاصة بك:
```env
NODE_ENV=production
PORT=3001
JWT_SECRET=your_secret_key
TWILIO_ACCOUNT_SID=your_twilio_sid
TWILIO_AUTH_TOKEN=your_twilio_token
STRIPE_SECRET_KEY=your_stripe_key
```

### 3. تشغيل السيرفر
```bash
node server.js
```

السيرفر سيعمل على `http://localhost:3001`

## 📁 هيكل المشروع

```
digital-store-saas/
├── server.js                    # الملف الرئيسي للسيرفر
├── .env                         # متغيرات البيئة
├── package.json
├── database.db                  # قاعدة البيانات (SQLite)
├── src/
│   ├── models/
│   │   └── database.js          # مخطط قاعدة البيانات
│   ├── controllers/
│   │   ├── authController.js    # منطق المصادقة
│   │   ├── storeController.js   # منطق المتاجر
│   │   ├── productController.js # منطق المنتجات
│   │   ├── orderController.js   # منطق الطلبات
│   │   └── couponController.js  # منطق أكواد الخصم
│   ├── routes/
│   │   ├── index.js             # التوجيهات الرئيسية
│   │   ├── auth.js              # توجيهات المصادقة
│   │   ├── stores.js            # توجيهات المتاجر
│   │   ├── products.js          # توجيهات المنتجات
│   │   ├── orders.js            # توجيهات الطلبات
│   │   ├── coupons.js           # توجيهات أكواد الخصم
│   │   ├── api.js               # توجيهات مفاتيح API
│   │   └── webhooks.js          # توجيهات الـ Webhooks
│   ├── middleware/
│   │   └── auth.js              # Middleware المصادقة
│   └── utils/
│       └── helpers.js           # دوال مساعدة
└── public/
    ├── index.html               # الصفحة الرئيسية
    ├── css/
    │   └── style.css            # التصاميم
    └── js/
        └── app.js               # منطق الواجهة الأمامية
```

## 🔌 API Endpoints

### المصادقة
```
POST   /api/auth/send-otp          - إرسال OTP
POST   /api/auth/verify-otp        - التحقق من OTP
GET    /api/auth/me                - الحصول على بيانات المستخدم
PUT    /api/auth/profile           - تحديث الملف الشخصي
```

### المتاجر
```
GET    /api/stores                 - الحصول على متاجر المستخدم
POST   /api/stores                 - إنشاء متجر جديد
GET    /api/stores/:storeId        - الحصول على تفاصيل المتجر
PUT    /api/stores/:storeId        - تحديث المتجر
GET    /api/stores/:storeId/stats  - الحصول على الإحصائيات
```

### المنتجات
```
GET    /api/products/:storeId                    - الحصول على المنتجات
GET    /api/products/:storeId/:productId         - تفاصيل المنتج
POST   /api/products/:storeId                    - إنشاء منتج
PUT    /api/products/:storeId/:productId         - تحديث المنتج
DELETE /api/products/:storeId/:productId         - حذف المنتج
```

### الطلبات
```
GET    /api/orders/:storeId                      - الحصول على الطلبات
GET    /api/orders/:storeId/:orderId             - تفاصيل الطلب
POST   /api/orders/:storeId                      - إنشاء طلب جديد
PUT    /api/orders/:storeId/:orderId             - تحديث حالة الطلب
```

### أكواد الخصم
```
GET    /api/coupons/:storeId                     - الحصول على الأكواد
POST   /api/coupons/:storeId                     - إنشاء كود جديد
PUT    /api/coupons/:storeId/:couponId           - تحديث الكود
DELETE /api/coupons/:storeId/:couponId           - حذف الكود
POST   /api/coupons/:storeId/validate            - التحقق من الكود
```

### مفاتيح API
```
GET    /api/api-keys/:storeId                    - الحصول على المفاتيح
POST   /api/api-keys/:storeId                    - إنشاء مفتاح جديد
DELETE /api/api-keys/:storeId/:keyId             - حذف المفتاح
```

### الـ Webhooks
```
GET    /api/webhooks/:storeId                    - الحصول على الـ Webhooks
POST   /api/webhooks/:storeId                    - إنشاء Webhook جديد
DELETE /api/webhooks/:storeId/:webhookId         - حذف Webhook
```

## 🔐 المصادقة

### استخدام JWT Token
```bash
curl -H "Authorization: Bearer YOUR_TOKEN" http://localhost:3001/api/auth/me
```

### استخدام API Key
```bash
curl -H "X-API-Key: YOUR_API_KEY" http://localhost:3001/api/products/store-id
```

## 📊 قاعدة البيانات

### الجداول الرئيسية
- **users** - بيانات المستخدمين
- **stores** - بيانات المتاجر
- **products** - بيانات المنتجات
- **categories** - تصنيفات المنتجات
- **orders** - بيانات الطلبات
- **order_items** - عناصر الطلبات
- **coupons** - أكواد الخصم
- **payment_methods** - طرق الدفع
- **reviews** - التقييمات
- **api_keys** - مفاتيح API
- **webhooks** - الـ Webhooks
- **analytics** - بيانات التحليلات
- **otp_sessions** - جلسات OTP

## 🚀 النشر

### على Heroku
```bash
heroku create your-app-name
git push heroku main
```

### على DigitalOcean
```bash
# إنشاء droplet
# تثبيت Node.js
# رفع الملفات
# تشغيل السيرفر
```

## 📝 الترخيص

MIT License

## 👨‍💻 الدعم

للمزيد من المعلومات، يرجى التواصل عبر البريد الإلكتروني أو فتح issue على GitHub.

---

**تم بناء هذه المنصة بواسطة فريق التطوير المتخصص**
